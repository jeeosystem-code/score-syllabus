package com.score1.syllabus
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Paper(val name: String, val max: Int)
data class TestCfg(val id: Int, val name: String, val date: String, val full: Boolean, val papers: List<Paper>, val time: String, val tag: String, val topics: List<String>)
data class ExamCfg(val name: String, val date: String?, val from: String?, val to: String?, val days: List<String>)
data class Config(val appName: String, val brand: String, val logo: Int, val subjects: List<String>, val target: ExamCfg?, val exams: List<ExamCfg>, val tests: List<TestCfg>)
class Ev(val d: LocalDate, val label: String, val full: Boolean, val name: String, val papers: List<Paper>)
class Test(val id: Int, val name: String, val d: String, val full: Boolean, val papers: List<Paper>, val time: String, val tag: String, val p: Map<String, List<String>>, val c: Map<String, List<String>>, val m: Map<String, List<String>>)

val EVENTS: List<Ev> get() = Cfg.events
val TESTS: List<Test> get() = Cfg.tests
val FULLS: List<Test> get() = Cfg.fulls
val SN: List<String> get() = Cfg.cur.subjects
val LOGO_BG = listOf("#0C1020", "#14213D", "#1B1B3A", "#0B3D2E", "#3A0E24", "#101820")
val LOGOS = listOf(R.drawable.logo_1, R.drawable.logo_2, R.drawable.logo_3, R.drawable.logo_4, R.drawable.logo_5, R.drawable.logo_6)

fun suf(i: Int) = if (i == 0) "" else ('a' + (i - 1)).toString()
fun rid(e: Ev, i: Int) = evId(e) + suf(i)
fun parseRid(id: String): Pair<String, Int> { val l = id.last(); return if (l.isLetter()) id.dropLast(1) to (l - 'a' + 1) else id to 0 }
fun pd(s: String?): LocalDate? = s?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

fun parseTopics(text: String): Map<String, List<String>> {
 val m = LinkedHashMap<String, MutableList<String>>(); var g = ""
 text.lines().forEach { raw -> val l = raw.trim(); if (l.isEmpty()) return@forEach; if (l.startsWith("#")) { g = l.removePrefix("#").trim(); return@forEach }; m.getOrPut(g) { mutableListOf() }.add(l) }
 return m
}
private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
fun Config.toJson(): JSONObject {
 fun ex(e: ExamCfg) = JSONObject().put("name", e.name).put("date", e.date ?: "").put("from", e.from ?: "").put("to", e.to ?: "").put("days", JSONArray(e.days))
 val o = JSONObject().put("app", JSONObject().put("name", appName).put("brand", brand).put("logo", logo)).put("subjects", JSONArray(subjects))
 if (target != null) o.put("target", ex(target))
 o.put("exams", JSONArray(exams.map { ex(it) }))
 o.put("tests", JSONArray(tests.map { t -> JSONObject().put("id", t.id).put("name", t.name).put("date", t.date).put("full", t.full).put("time", t.time).put("tag", t.tag).put("papers", JSONArray(t.papers.map { JSONObject().put("name", it.name).put("max", it.max) })).put("topics", JSONArray(t.topics)) }))
 return o
}
fun parseConfig(o: JSONObject): Config {
 fun ex(x: JSONObject) = ExamCfg(x.optString("name"), x.optString("date").ifEmpty { null }, x.optString("from").ifEmpty { null }, x.optString("to").ifEmpty { null }, strs(x.optJSONArray("days")))
 val app = o.optJSONObject("app") ?: JSONObject()
 val sj = strs(o.optJSONArray("subjects")).let { if (it.size >= 3) it.take(3) else listOf("Physics", "Chemistry", "Mathematics") }
 val exs = o.optJSONArray("exams")?.let { a -> (0 until a.length()).map { ex(a.getJSONObject(it)) } } ?: emptyList()
 val ts = o.optJSONArray("tests")?.let { a -> (0 until a.length()).map { i -> val t = a.getJSONObject(i)
  val pa = t.optJSONArray("papers")?.let { b -> (0 until b.length()).map { Paper(b.getJSONObject(it).optString("name"), b.getJSONObject(it).optInt("max", 100)) } } ?: listOf(Paper("Paper 1", 100))
  TestCfg(t.optInt("id"), t.optString("name"), t.optString("date"), t.optBoolean("full"), pa, t.optString("time"), t.optString("tag"), strs(t.optJSONArray("topics")).let { it + List(3) { "" } }.take(3)) } } ?: emptyList()
 return Config(app.optString("name", "My Tracker"), app.optString("brand"), app.optInt("logo", 1), sj, o.optJSONObject("target")?.let { ex(it) }, exs, ts)
}

object Cfg {
 var cur by mutableStateOf(blank())
 var needsBuilder = false
 private var loaded = false
 private var cache: Pair<Config, Triple<List<Test>, List<Test>, List<Ev>>>? = null
 fun blank() = Config("My Tracker", "", 1, listOf("Physics", "Chemistry", "Mathematics"), null, emptyList(), emptyList())
 private fun build(c: Config): Triple<List<Test>, List<Test>, List<Ev>> {
  val all = c.tests.mapNotNull { t -> pd(t.date)?.let { t to it } }.sortedBy { it.second.toEpochDay() }
  fun mk(t: TestCfg): Test { val g = t.topics + List(3) { "" }; return Test(t.id, t.name, t.date, t.full, t.papers, t.time, t.tag, parseTopics(g[0]), parseTopics(g[1]), parseTopics(g[2])) }
  return Triple(all.filter { !it.first.full }.map { mk(it.first) }, all.filter { it.first.full }.map { mk(it.first) }, all.map { (t, d) -> Ev(d, (if (t.full) "F" else "PT") + t.id, t.full, t.name, t.papers) })
 }
 private fun built(): Triple<List<Test>, List<Test>, List<Ev>> { val c = cur; cache?.let { if (it.first === c) return it.second }; val b = build(c); cache = c to b; return b }
 val tests: List<Test> get() = built().first
 val fulls: List<Test> get() = built().second
 val events: List<Ev> get() = built().third
 val totalPapers: Int get() = events.sumOf { it.papers.size }
 val flagged: Boolean get() = tests.any { t -> listOf(t.p, t.c, t.m).any { m -> m.values.any { l -> l.any { it.startsWith("m:") || it.startsWith("a:") } } } }
 fun allExams(): List<ExamCfg> = listOfNotNull(cur.target) + cur.exams
 fun range(): Pair<LocalDate, LocalDate> {
  val today = LocalDate.now(); val ds = mutableListOf<LocalDate>()
  events.forEach { ds += it.d }
  allExams().forEach { e -> listOf(e.date, e.from, e.to).forEach { s -> pd(s)?.let { ds += it } } }
  if (ds.isEmpty()) return today.minusDays(1) to today.plusDays(30)
  val sorted = ds.sortedBy { it.toEpochDay() }; var a = sorted.first().minusDays(3); val b = sorted.last().plusDays(4)
  if (today.isBefore(a) && ChronoUnit.DAYS.between(today, a) < 120) a = today.minusDays(1)
  return a to b
 }
 private fun asset(c: Context, n: String): String? = try { c.assets.open(n).bufferedReader().use { it.readText() } } catch (e: Exception) { null }
 fun preset(c: Context): Config = runCatching { parseConfig(JSONObject(asset(c, "preset.json")!!)) }.getOrNull() ?: blank()
 fun ensure(c: Context) {
  if (loaded) return; loaded = true
  val pr = c.getSharedPreferences("s1", 0); val legacy = pr.contains("total") || pr.contains("keys")
  val origin = pr.getString("origin", null) ?: (if (legacy) "preset" else "blank").also { pr.edit().putString("origin", it).apply() }
  val saved = pr.getString("cfg", null)?.let { runCatching { parseConfig(JSONObject(it)) }.getOrNull() }
  val bundled = asset(c, "tracker.json")?.let { runCatching { parseConfig(JSONObject(it).getJSONObject("config")) }.getOrNull() }
  var cfg = saved ?: bundled
  if (cfg == null && origin == "preset") { cfg = preset(c); val old = pd(pr.getString("jee", null)); if (old != null && cfg.target != null) cfg = cfg.copy(target = cfg.target!!.copy(date = old.toString())) }
  needsBuilder = cfg == null && !pr.getBoolean("builderShown", false)
  cur = cfg ?: blank()
 }
 fun applyCfg(pr: SharedPreferences, c: Config) { cur = c; pr.edit().putString("cfg", c.toJson().toString()).putBoolean("builderShown", true).apply() }
 fun setExamDate(pr: SharedPreferences, i: Int, d: String?) {
  val c = cur; val t = c.target
  applyCfg(pr, if (t != null) { if (i == 0) c.copy(target = t.copy(date = d)) else c.copy(exams = c.exams.mapIndexed { k, e -> if (k == i - 1) e.copy(date = d) else e }) } else c.copy(exams = c.exams.mapIndexed { k, e -> if (k == i) e.copy(date = d) else e }))
 }
}
