@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
package com.score1.syllabus
import android.app.Activity
import android.content.SharedPreferences
import android.view.View
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as DTS
import java.time.temporal.ChronoUnit
import java.util.Locale

class Pal(val bg: Color, val s1: Color, val s2: Color, val tx: Color, val mu: Color, val ln: Color, val P: Color, val C: Color, val M: Color, val ok: Color, val dark: Boolean) { fun sub(i: Int) = when (i) { 0 -> P; 1 -> C; else -> M } }
val DarkP = Pal(Color(0xFF0C1020), Color(0xFF151A31), Color(0xFF1D2342), Color(0xFFEDEFFA), Color(0xFF8F97BA), Color(0xFF272E52), Color(0xFF4CC9F0), Color(0xFFFFB547), Color(0xFFB58CFF), Color(0xFF5EE6A8), true)
val LightP = Pal(Color(0xFFF2F3F9), Color(0xFFFFFFFF), Color(0xFFE8EAF4), Color(0xFF10142E), Color(0xFF5B6280), Color(0xFFD9DCEB), Color(0xFF0A84B8), Color(0xFFC77700), Color(0xFF7B3FE4), Color(0xFF0E9F6E), false)
val PH = listOf("Phase I" to "Part Tests 1–2 · revision classes start 26 Oct", "Phase II" to "Part Tests 3–4 · revision classes start 23 Nov", "Phase III" to "Part Tests 5–6 · revision classes start 14 Dec")
val FT = listOf("9:00 AM – 12:00 noon", "3:00 – 6:00 PM", "9:00 AM – 12:00 noon", "3:00 – 6:00 PM", "9:00 AM – 12:00 noon")
val SN = listOf("Physics", "Chemistry", "Mathematics")
val DM: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
class Topic(val flag: Char, val text: String, val key: String)
sealed class Rw { data class T(val id: Int) : Rw(); data class F(val i: Int) : Rw(); object FH : Rw(); object Foot : Rw() }

class UiState(val store: Store, val prefs: SharedPreferences) {
 var mode by mutableStateOf(prefs.getInt("mode", 0)); val subj = mutableStateListOf(true, true, true); var q by mutableStateOf("")
 var done by mutableStateOf(setOf<String>()); val open = mutableStateMapOf<Int, Boolean>()
 var flash by mutableStateOf<String?>(null); var theme by mutableStateOf(0); var backup by mutableStateOf(false)
 var hf: HapticFeedback? = null
 fun tick() { hf?.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
 fun toggle(k: String) { val on = k !in done; done = if (on) done + k else done - k; store.set(k, on); store.mirror(done); tick() }
 fun restore(keys: List<String>) { done = keys.toSet(); store.replace(done); store.mirror(done) }
 fun setMode(i: Int) { mode = i; prefs.edit().putInt("mode", i).apply() }
 fun cycleTheme() { theme = (theme + 1) % 3; prefs.edit().putInt("theme", theme).apply() }
 fun vis(f: Char) = vis(mode, f)
 fun groups(t: Test, s: Int): List<Pair<String, List<Topic>>> {
  val m = when (s) { 0 -> t.p; 1 -> t.c; else -> t.m }
  return m.map { (g, l) -> g to l.map { x -> val f = if (x.startsWith("m:")) 'm' else if (x.startsWith("a:")) 'a' else ' '; val tx = if (f == ' ') x else x.substring(2); Topic(f, tx, "${t.id}|${"PCM"[s]}|$tx") }.filter { vis(it.flag) && (q.isBlank() || it.text.contains(q, true)) } }.filter { it.second.isNotEmpty() }
 }
}

@Composable fun Tx(s: String, c: Color, sz: Float, w: FontWeight = FontWeight.Normal, m: Modifier = Modifier, ls: Float = 0f, align: TextAlign = TextAlign.Start, lh: Float = 0f) =
 BasicText(s, m, style = TextStyle(color = c, fontSize = sz.sp, fontWeight = w, letterSpacing = ls.sp, textAlign = align, lineHeight = if (lh > 0f) lh.sp else TextUnit.Unspecified))
fun hl(s: String, q: String, c: Color) = buildAnnotatedString {
 if (q.isBlank()) { append(s); return@buildAnnotatedString }
 var i = 0; val l = s.lowercase(); val k = q.lowercase()
 while (true) { val j = l.indexOf(k, i); if (j < 0) { append(s.substring(i)); break }; append(s.substring(i, j)); withStyle(SpanStyle(background = c)) { append(s.substring(j, j + k.length)) }; i = j + k.length }
}

@Composable fun App(st: UiState) {
 val sys = isSystemInDarkTheme(); val p = when (st.theme) { 1 -> LightP; 2 -> DarkP; else -> if (sys) DarkP else LightP }
 st.hf = LocalHapticFeedback.current
 val view = LocalView.current
 SideEffect { val w = (view.context as Activity).window; w.statusBarColor = p.bg.toArgb(); w.navigationBarColor = p.bg.toArgb(); w.decorView.systemUiVisibility = if (p.dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR }
 val ls = rememberLazyListState(); val scope = rememberCoroutineScope(); var hdr by remember { mutableIntStateOf(0) }
 val rows = remember { val l = mutableListOf<Rw>(); TESTS.forEach { l += Rw.T(it.id) }; l += Rw.FH; (0..4).forEach { l += Rw.F(it) }; l += Rw.Foot; l.toList() }
 fun jump(e: Ev) {
  val n = e.label.filter { it.isDigit() }.toInt()
  val target: Rw = if (e.full) Rw.F(n - 1) else Rw.T(n)
  if (!e.full) st.open[n] = true
  st.flash = (if (e.full) "f" else "pt") + n; st.hf?.performHapticFeedback(HapticFeedbackType.LongPress)
  scope.launch { ls.animateScrollToItem(rows.indexOf(target) + 3, -(hdr + 16)); delay(1700); st.flash = null }
 }
 Box(Modifier.fillMaxSize().background(p.bg)) {
  LazyColumn(state = ls, modifier = Modifier.fillMaxSize()) {
   item { Hero(p, st) { jump(it) } }
   stickyHeader { Controls(p, st, Modifier.onSizeChanged { hdr = it.height }) }
   item { Spacer(Modifier.height(14.dp)) }
   items(rows) { r ->
    when (r) {
     is Rw.T -> TestCard(TESTS.first { it.id == r.id }, p, st)
     Rw.FH -> Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 12.dp)) { Tx("Full syllabus tests", p.tx, 24f, FontWeight.ExtraBold, ls = -.5f) }
     is Rw.F -> FullCard(r.i, p, st)
     Rw.Foot -> Column(Modifier.padding(16.dp).clip(RoundedCornerShape(18.dp)).background(p.s2).padding(18.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Tx("JEE Main, Session 1: 22–24 and 28–30 Jan 2027, with 31 Jan 2027 as buffer.", p.mu, 13f)
      Tx("Enthusiast course students join SCORE-I according to their course completion. Outside Kota you can attempt tests on the ALLEN App, but results are not counted in AIR.", p.mu, 13f)
      Tx("Tap a topic to mark it studied. Marks are saved in a database on this phone. Use Backup to keep a copy.", p.mu, 13f) }
    }
   }
  }
 }
 if (st.backup) BackupDialog(p, st)
}

@Composable fun Hero(p: Pal, st: UiState, onNode: (Ev) -> Unit) {
 val today = LocalDate.now(); val nx = EVENTS.firstOrNull { !it.d.isBefore(today) }; val n = if (nx != null) ChronoUnit.DAYS.between(today, nx.d).toInt() else 0
 var go by remember { mutableStateOf(false) }; LaunchedEffect(Unit) { go = true }
 val wipe by animateFloatAsState(if (go) 1f else 0f, tween(1000, easing = CubicBezierEasing(.7f, 0f, .2f, 1f)), label = "w")
 val shown by animateIntAsState(if (go) n else 0, tween(1100, 300, FastOutSlowInEasing), label = "n")
 val head = buildAnnotatedString {
  if (nx == null) append("SCORE-I is complete") else if (n == 0) append("${nx.name} is today") else { append(nx.name + " is "); withStyle(SpanStyle(color = p.M)) { append("$shown") }; append(if (n == 1) " day away" else " days away") }
 }
 Column(Modifier.padding(top = 20.dp)) {
  Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(6.dp).graphicsLayer { scaleX = wipe; transformOrigin = TransformOrigin(0f, .5f) }.clip(RoundedCornerShape(3.dp))) { listOf(p.P, p.C, p.M).forEach { Box(Modifier.weight(1f).fillMaxHeight().background(it)) } }
  Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
   Tx("ALLEN Enthusiast · IIT-JEE 2026–27", p.mu, 13f)
   Box(Modifier.clip(CircleShape).background(p.s1).border(1.dp, p.ln, CircleShape).clickable { st.cycleTheme() }.padding(horizontal = 14.dp, vertical = 6.dp)) { Tx(listOf("Theme: auto", "Theme: light", "Theme: dark")[st.theme], p.tx, 12f) }
  }
  BasicText(head, Modifier.padding(horizontal = 20.dp), style = TextStyle(color = p.tx, fontSize = 40.sp, lineHeight = 42.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.2).sp))
  Tx(if (nx != null && n > 1) "${n - 1} full days to prepare between today and test day. Tap a milestone below to jump to it." else "Tap a milestone below to jump to it.", p.mu, 15f, m = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
  Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
   Stat(p, "${EVENTS.size}", "tests to take", Modifier.weight(1f)); Stat(p, "6 + 5", "part + full", Modifier.weight(1f))
   val ov = overallPct(st.mode, st.done); Stat(p, "${Math.round(ov * 100)}%", "of syllabus done", Modifier.weight(1.3f), ov)
  }
  Runway(p, onNode)
 }
}
@Composable fun Stat(p: Pal, big: String, small: String, m: Modifier, frac: Float? = null) {
 Column(m.clip(RoundedCornerShape(14.dp)).background(p.s1).border(1.dp, p.ln, RoundedCornerShape(14.dp)).padding(12.dp)) {
  Tx(big, p.tx, 20f, FontWeight.ExtraBold, ls = -.4f); Tx(small, p.mu, 12f)
  if (frac != null) { val a by animateFloatAsState(frac, tween(600), label = "sb"); Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.ok)) } }
 }
}

@Composable fun Runway(p: Pal, onNode: (Ev) -> Unit) {
 val s0 = LocalDate.of(2026, 10, 26); val s1 = LocalDate.of(2027, 1, 31); val tot = ChronoUnit.DAYS.between(s0, s1).toFloat(); val W = 748f
 fun fr(d: LocalDate) = (ChronoUnit.DAYS.between(s0, d) / tot).coerceIn(0f, 1f)
 fun x(d: LocalDate) = (16f + W * fr(d)).dp
 val today = LocalDate.now(); val nx = EVENTS.firstOrNull { !it.d.isBefore(today) }
 var go by remember { mutableStateOf(false) }; LaunchedEffect(Unit) { go = true }
 val fill by animateFloatAsState(if (go) fr(today) else 0f, tween(1800, 500, CubicBezierEasing(.5f, 0f, .1f, 1f)), label = "f")
 Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
  Box(Modifier.width(780.dp).height(104.dp)) {
   Box(Modifier.offset(16.dp, 50.dp).width(W.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(p.s2))
   Box(Modifier.offset(16.dp, 50.dp).width((W * fill).dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Brush.horizontalGradient(listOf(p.P, p.C, p.M))))
   val jx = x(LocalDate.of(2027, 1, 22))
   Canvas(Modifier.offset(jx, 40.dp).size((16f + W).dp - jx + 8.dp, 24.dp)) { drawRoundRect(p.mu, cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))) }
   Tx("JEE Main", p.mu, 10f, m = Modifier.offset(jx + 6.dp, 84.dp))
   if (!today.isBefore(s0) && today.isBefore(s1)) { Box(Modifier.offset(x(today) - 1.dp, 38.dp).width(2.dp).height(30.dp).background(p.ok)); Tx("Today", p.ok, 10f, FontWeight.Bold, Modifier.offset(x(today) - 20.dp, 86.dp).width(40.dp), align = TextAlign.Center) }
   EVENTS.forEachIndexed { i, e ->
    val nxt = e === nx
    if (nxt) Tx("${e.label} · ${e.d.format(DM)}", p.M, 11f, FontWeight.Bold, Modifier.offset(x(e.d) - 45.dp, 2.dp).width(90.dp), align = TextAlign.Center)
    else { Tx(e.label, p.tx, 11f, FontWeight.Bold, Modifier.offset(x(e.d) - 18.dp, 20.dp).width(36.dp), align = TextAlign.Center); Tx(e.d.format(DM), p.mu, 9f, m = Modifier.offset(x(e.d) - 18.dp, 68.dp).width(36.dp), align = TextAlign.Center) }
    Node(e, i, x(e.d), e.d.isBefore(today), nxt, p) { onNode(e) }
   }
  }
 }
}
@Composable fun Node(e: Ev, i: Int, x: Dp, past: Boolean, next: Boolean, p: Pal, onClick: () -> Unit) {
 val sc = remember { Animatable(0f) }; LaunchedEffect(Unit) { delay(300L + i * 110L); sc.animateTo(1f, spring(0.45f, 320f)) }
 val pulse = if (next) rememberInfiniteTransition(label = "p").animateFloat(0f, 1f, infiniteRepeatable(tween(1800)), label = "pp").value else 0f
 Box(Modifier.offset(x - 18.dp, 32.dp).size(36.dp).clickable(onClick = onClick)) {
  Canvas(Modifier.fillMaxSize().graphicsLayer { scaleX = sc.value; scaleY = sc.value }) {
   val c = center; val r = 9.dp.toPx(); val col = if (next) p.M else p.tx; val sw = 2.dp.toPx()
   if (next) drawCircle(p.M.copy(alpha = (1f - pulse) * .5f), radius = r + pulse * 10.dp.toPx(), center = c)
   if (e.full) rotate(45f, c) { val s = r * .95f; drawRoundRect(if (past) col else p.bg, Offset(c.x - s, c.y - s), Size(2 * s, 2 * s), CornerRadius(3.dp.toPx())); drawRoundRect(col, Offset(c.x - s, c.y - s), Size(2 * s, 2 * s), CornerRadius(3.dp.toPx()), style = Stroke(sw)) }
   else { drawCircle(if (past) col else p.bg, radius = r, center = c); drawCircle(col, radius = r, center = c, style = Stroke(sw)) }
  }
 }
}

@Composable fun Pill(p: Pal, text: String, col: Color? = null, sel: Boolean = false, onClick: () -> Unit) {
 val c = col ?: p.tx
 val bgc by animateColorAsState(if (sel) c else Color.Transparent, tween(250), label = "pb"); val fg by animateColorAsState(if (sel) p.bg else c, tween(250), label = "pf")
 Box(Modifier.clip(CircleShape).background(if (col == null) p.s1 else Color.Transparent).background(bgc).border(1.5.dp, if (col == null) p.ln else c, CircleShape).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)) { Tx(text, fg, 14f, FontWeight.SemiBold) }
}
@Composable fun Controls(p: Pal, st: UiState, m: Modifier) {
 Column(m.fillMaxWidth().background(p.bg.copy(alpha = .96f))) {
  FlowRow(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
   val off by animateDpAsState((st.mode * 86).dp, spring(0.7f, 400f), label = "seg")
   Box(Modifier.clip(CircleShape).background(p.s2).padding(3.dp)) {
    Box(Modifier.offset(x = off).size(86.dp, 32.dp).clip(CircleShape).background(p.tx))
    Row { listOf("Both", "Main", "Advanced").forEachIndexed { i, l -> val fg by animateColorAsState(if (st.mode == i) p.bg else p.tx, tween(250), label = "sf"); Box(Modifier.size(86.dp, 32.dp).clip(CircleShape).clickable { st.setMode(i); st.tick() }, Alignment.Center) { Tx(l, fg, 14f, FontWeight.SemiBold) } } }
   }
   SN.forEachIndexed { i, n -> Pill(p, n, p.sub(i), st.subj[i]) { st.subj[i] = !st.subj[i]; st.tick() } }
   Box(Modifier.width(200.dp).height(36.dp).clip(CircleShape).background(p.s1).border(1.dp, p.ln, CircleShape).padding(horizontal = 14.dp), Alignment.CenterStart) {
    if (st.q.isEmpty()) Tx("Search a topic, e.g. SHM", p.mu, 14f)
    BasicTextField(st.q, { st.q = it }, Modifier.fillMaxWidth(), singleLine = true, textStyle = TextStyle(color = p.tx, fontSize = 14.sp), cursorBrush = SolidColor(p.M))
   }
   val allOpen = TESTS.all { st.open[it.id] == true }
   Pill(p, if (allOpen) "Collapse all" else "Expand all") { TESTS.forEach { st.open[it.id] = !allOpen } }
   Pill(p, "Backup") { st.backup = true }
  }
  Box(Modifier.fillMaxWidth().height(1.dp).background(p.ln))
 }
}

@Composable fun TestCard(t: Test, p: Pal, st: UiState) {
 val g = (0..2).map { if (st.subj[it]) st.groups(t, it) else emptyList() }
 if (g.all { it.isEmpty() }) return
 val open = st.open[t.id] == true || st.q.isNotBlank()
 val frac = testPct(t, st.mode, st.done)
 val pr by animateFloatAsState(frac, tween(500), label = "r"); val chev by animateFloatAsState(if (open) 180f else 0f, spring(0.7f, 300f), label = "c")
 val flashing = st.flash == "pt${t.id}"; val shape = RoundedCornerShape(18.dp)
 val bc by animateColorAsState(if (flashing) p.M else if (open) p.mu else p.ln, tween(350), label = "b")
 val sc by animateFloatAsState(if (flashing) 1.02f else 1f, spring(.5f, 300f), label = "s")
 val d = LocalDate.parse(t.d)
 Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(shape).background(p.s1).border(if (flashing) 2.dp else 1.dp, bc, shape)) {
  Row(Modifier.fillMaxWidth().clickable { st.open[t.id] = !open }.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
   Column(Modifier.width(48.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("${d.dayOfMonth}", p.tx, 32f, FontWeight.ExtraBold, ls = -1f); Tx(d.month.getDisplayName(DTS.SHORT, Locale.ENGLISH), p.mu, 12f) }
   Column(Modifier.weight(1f)) {
    Tx("Part Test ${t.id}", p.tx, 19f, FontWeight.Bold, ls = -.3f); Tx("${d.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH)} · Main + Advanced · two papers", p.mu, 12f)
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
     (0..2).forEach { s -> val f = subFrac(t, s, st.mode, st.done); val af by animateFloatAsState(f, tween(500), label = "m")
      Box(Modifier.width(38.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(af).background(p.sub(s))) } }
    }
   }
   Box(Modifier.size(46.dp), Alignment.Center) {
    Canvas(Modifier.fillMaxSize()) { val sw = 5.dp.toPx(); val sz = size.minDimension - sw; val tl = Offset(sw / 2, sw / 2); drawArc(p.s2, 0f, 360f, false, tl, Size(sz, sz), style = Stroke(sw)); drawArc(p.ok, -90f, 360f * pr, false, tl, Size(sz, sz), style = Stroke(sw, cap = StrokeCap.Round)) }
    Tx("${Math.round(pr * 100)}%", p.tx, 11f, FontWeight.SemiBold)
   }
   Canvas(Modifier.size(12.dp).rotate(chev)) { val w = 2.dp.toPx(); drawLine(p.mu, Offset(1.dp.toPx(), 3.dp.toPx()), Offset(6.dp.toPx(), 8.dp.toPx()), w, StrokeCap.Round); drawLine(p.mu, Offset(6.dp.toPx(), 8.dp.toPx()), Offset(11.dp.toPx(), 3.dp.toPx()), w, StrokeCap.Round) }
  }
  AnimatedVisibility(open, enter = expandVertically(spring(.8f, 300f)) + fadeIn(tween(300)), exit = shrinkVertically(tween(250)) + fadeOut(tween(150))) {
   Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    (0..2).forEach { s ->
     if (g[s].isNotEmpty()) Column {
      Box(Modifier.fillMaxWidth().height(3.dp).background(p.sub(s))); Tx(SN[s], p.sub(s), 16f, FontWeight.Bold, Modifier.padding(top = 8.dp))
      g[s].forEach { (gn, list) ->
       if (gn.isNotEmpty()) Tx(gn, p.mu, 12f, FontWeight.SemiBold, Modifier.padding(top = 8.dp))
       FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { list.forEach { tp -> Chip(tp, p.sub(s), p, tp.key in st.done, st.q) { st.toggle(tp.key) } } }
      }
     }
    }
   }
  }
 }
}
@Composable fun Chip(tp: Topic, col: Color, p: Pal, on: Boolean, q: String, onClick: () -> Unit) {
 val bgc by animateColorAsState(if (on) col else col.copy(alpha = .12f), tween(250), label = "cb"); val fg by animateColorAsState(if (on) p.bg else p.tx, tween(250), label = "cf")
 val sc = remember { Animatable(1f) }; var first by remember { mutableStateOf(true) }
 LaunchedEffect(on) { if (first) first = false else { sc.snapTo(.9f); sc.animateTo(1f, spring(0.35f, 400f)) } }
 val shape = RoundedCornerShape(10.dp)
 Row(Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value }.clip(shape).background(bgc)
  .then(if (tp.flag == ' ') Modifier.border(1.dp, col.copy(alpha = .5f), shape) else Modifier.drawBehind { drawRoundRect(col.copy(alpha = .8f), cornerRadius = CornerRadius(10.dp.toPx()), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))) })
  .clickable(onClick = onClick).padding(start = 9.dp, end = 10.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
  Box(Modifier.size(12.dp).border(1.5.dp, if (on) p.bg else col, CircleShape), Alignment.Center) { if (on) Box(Modifier.size(6.dp).clip(CircleShape).background(p.bg)) }
  Spacer(Modifier.width(6.dp))
  BasicText(hl(tp.text, q, p.M.copy(alpha = .35f)), style = TextStyle(color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium))
  if (tp.flag != ' ') Tx(if (tp.flag == 'm') "  Main" else "  Adv", fg, 11f, FontWeight.SemiBold)
 }
}
@Composable fun FullCard(i: Int, p: Pal, st: UiState) {
 val e = EVENTS[6 + i]; val flashing = st.flash == "f${i + 1}"; val shape = RoundedCornerShape(18.dp); val today = LocalDate.now(); val n = ChronoUnit.DAYS.between(today, e.d).toInt()
 val bgc by animateColorAsState(if (flashing) p.M.copy(alpha = .2f) else p.s1, tween(350), label = "fb"); val bc by animateColorAsState(if (flashing) p.M else p.ln, tween(350), label = "fc")
 val sc by animateFloatAsState(if (flashing) 1.03f else 1f, spring(.45f, 300f), label = "fs")
 Row(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp).graphicsLayer { scaleX = sc; scaleY = sc }.fillMaxWidth().clip(shape).background(bgc).border(if (flashing) 2.dp else 1.dp, bc, shape).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
  Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("${e.d.dayOfMonth}", p.tx, 32f, FontWeight.ExtraBold, ls = -1f); Tx(e.d.month.getDisplayName(DTS.SHORT, Locale.ENGLISH), p.mu, 12f) }
  Column(Modifier.weight(1f)) {
   Tx("Full test ${i + 1}", p.tx, 18f, FontWeight.Bold); Tx("${e.d.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH)} · ${FT[i]}", p.mu, 13f)
   Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    Box(Modifier.clip(CircleShape).background(if (i == 2) p.M else p.s2).padding(horizontal = 10.dp, vertical = 3.dp)) { Tx(if (i == 2) "AIOT · Full syllabus" else "Full syllabus", if (i == 2) p.bg else p.tx, 12f, FontWeight.SemiBold) }
    Tx(if (n < 0) "Done" else if (n == 0) "Today" else "In $n days", if (n < 0) p.ok else p.mu, 12f, m = Modifier.align(Alignment.CenterVertically))
   }
  }
 }
}
@Composable fun BackupDialog(p: Pal, st: UiState) {
 var text by remember { mutableStateOf(JSONObject().put("v", 1).put("done", JSONArray(st.done.toList())).toString()) }; var msg by remember { mutableStateOf("") }
 val cb = LocalClipboardManager.current; val shape = RoundedCornerShape(18.dp)
 Dialog(onDismissRequest = { st.backup = false }) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
   Tx("Backup and restore", p.tx, 22f, FontWeight.ExtraBold)
   Tx("Your marks live in a database on this phone. Copy this text to keep a backup, or paste a saved one and restore it.", p.mu, 14f)
   BasicTextField(text, { text = it }, Modifier.fillMaxWidth().heightIn(max = 160.dp).clip(RoundedCornerShape(12.dp)).background(p.bg).padding(10.dp), textStyle = TextStyle(color = p.tx, fontSize = 12.sp, fontFamily = FontFamily.Monospace), cursorBrush = SolidColor(p.M))
   if (msg.isNotEmpty()) Tx(msg, p.ok, 13f)
   FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Copy backup") { cb.setText(AnnotatedString(text)); msg = "Copied." }
    Pill(p, "Restore") { try { val a = JSONObject(text).getJSONArray("done"); st.restore((0 until a.length()).map { a.getString(it) }); msg = "Restored ${a.length()} topics." } catch (e: Exception) { msg = "That doesn’t look like a backup." } }
    Pill(p, "Close") { st.backup = false }
   }
  }
 }
}
