package com.score1.syllabus
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.res.Configuration
import android.graphics.*
import android.widget.RemoteViews
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.sqrt
class Ev(val d: LocalDate, val label: String, val full: Boolean, val name: String)
val EVENTS: List<Ev> = listOf("2026-11-03", "2026-11-23", "2026-12-02", "2026-12-11", "2026-12-20", "2026-12-29").mapIndexed { i, s -> Ev(LocalDate.parse(s), "PT${i + 1}", false, "Part Test ${i + 1}") } +
 listOf("2027-01-02", "2027-01-06", "2027-01-10", "2027-01-13", "2027-01-18").mapIndexed { i, s -> Ev(LocalDate.parse(s), "F${i + 1}", true, "Full test ${i + 1}") }
class ScoreWidget : AppWidgetProvider() {
 override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { update(c, m, it) } }
 override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) { update(c, m, id) }
 override fun onReceive(c: Context, i: Intent) { super.onReceive(c, i); if (i.action != AppWidgetManager.ACTION_APPWIDGET_UPDATE && i.action != null) refresh(c) }
 companion object {
  fun refresh(c: Context) { val m = AppWidgetManager.getInstance(c); m.getAppWidgetIds(ComponentName(c, ScoreWidget::class.java)).forEach { update(c, m, it) } }
  fun update(c: Context, m: AppWidgetManager, id: Int) {
   val o = m.getAppWidgetOptions(id); var d = c.resources.displayMetrics.density
   val port = c.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
   var w = (o.getInt(if (port) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 300) * d).toInt()
   var h = (o.getInt(if (port) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 200) * d).toInt()
   if (w < 50 || h < 50) return
   if (w * h > 1_000_000) { val f = sqrt(1_000_000f / (w * h)); w = (w * f).toInt(); h = (h * f).toInt(); d *= f }
   val rv = RemoteViews(c.packageName, R.layout.widget)
   rv.setImageViewBitmap(R.id.img, draw(c, w, h, d))
   rv.setOnClickPendingIntent(R.id.img, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
   m.updateAppWidget(id, rv)
  }
  fun draw(c: Context, w: Int, h: Int, d: Float): Bitmap {
   val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
   fun col(l: String, k: String) = Color.parseColor(if (night) k else l)
   val bg = col("#FFFFFF", "#151A31"); val ln = col("#D9DCEB", "#272E52"); val tx = col("#10142E", "#EDEFFA"); val mu = col("#5B6280", "#8F97BA"); val s2 = col("#E8EAF4", "#1D2342")
   val cP = col("#0A84B8", "#4CC9F0"); val cC = col("#C77700", "#FFB547"); val cM = col("#7B3FE4", "#B58CFF"); val ok = col("#0E9F6E", "#5EE6A8")
   val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp); val p = Paint(Paint.ANTI_ALIAS_FLAG)
   val bold = Typeface.create("sans-serif", Typeface.BOLD); val med = Typeface.create("sans-serif-medium", Typeface.NORMAL)
   fun txt(s: String, x: Float, y: Float, sz: Float, color: Int, tf: Typeface, al: Paint.Align = Paint.Align.LEFT) { p.style = Paint.Style.FILL; p.textSize = sz; p.typeface = tf; p.color = color; p.textAlign = al; cv.drawText(s, x, y, p) }
   val r = 22 * d; p.color = bg; cv.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), r, r, p)
   p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = ln; cv.drawRoundRect(d / 2, d / 2, w - d / 2, h - d / 2, r, r, p); p.style = Paint.Style.FILL
   val pad = 16 * d; val iw = w - 2 * pad
   val sp = Path().apply { addRoundRect(pad, pad, pad + iw, pad + 5 * d, 2.5f * d, 2.5f * d, Path.Direction.CW) }
   cv.save(); cv.clipPath(sp); listOf(cP, cC, cM).forEachIndexed { i, k -> p.color = k; cv.drawRect(pad + iw / 3 * i, pad, pad + iw / 3 * (i + 1), pad + 5 * d, p) }; cv.restore()
   txt("ALLEN Enthusiast · IIT-JEE 2026–27", pad, 38 * d, 11 * d, mu, med)
   val today = LocalDate.now(); val nx = EVENTS.firstOrNull { !it.d.isBefore(today) }; val n = if (nx != null) ChronoUnit.DAYS.between(today, nx.d).toInt() else 0
   val parts: List<Pair<String, Int>> = if (nx == null) listOf("SCORE-I is complete" to tx) else if (n == 0) listOf("${nx.name} is today" to tx) else listOf("${nx.name} is " to tx, "$n" to cM, (if (n == 1) " day away" else " days away") to tx)
   var sz = 26 * d; p.typeface = bold
   fun tw(s: Float): Float { p.textSize = s; return parts.sumOf { p.measureText(it.first).toDouble() }.toFloat() }
   while (tw(sz) > iw && sz > 13 * d) sz -= d / 2
   var x = pad; parts.forEach { (s, k) -> txt(s, x, 70 * d, sz, k, bold); x += p.measureText(s) }
   txt(if (nx != null && n > 1) "${n - 1} full days to prepare" else "Open the app to see topics", pad, 90 * d, 12 * d, mu, med)
   val keys = try { JSONArray(c.getSharedPreferences("s1", 0).getString("keys", "[]")).length() } catch (e: Exception) { 0 }
   val total = c.getSharedPreferences("s1", 0).getInt("total", 0)
   if (h >= 185 * d) {
    val s0 = LocalDate.of(2026, 10, 26); val s1 = LocalDate.of(2027, 1, 31); val x0 = pad + 8 * d; val x1 = w - pad - 8 * d; val ry = 134 * d
    fun xo(t: LocalDate) = x0 + (x1 - x0) * (ChronoUnit.DAYS.between(s0, t).toFloat() / ChronoUnit.DAYS.between(s0, s1)).coerceIn(0f, 1f)
    p.color = s2; cv.drawRoundRect(x0, ry - 2 * d, x1, ry + 2 * d, 2 * d, 2 * d, p)
    val jx = xo(LocalDate.of(2027, 1, 22)); p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = mu; p.pathEffect = DashPathEffect(floatArrayOf(4 * d, 3 * d), 0f)
    cv.drawRoundRect(jx, ry - 9 * d, x1 + 4 * d, ry + 9 * d, 9 * d, 9 * d, p); p.pathEffect = null; p.style = Paint.Style.FILL
    txt("JEE Main", jx, ry + 28 * d, 9 * d, mu, med)
    val tx0 = xo(today); p.shader = LinearGradient(x0, 0f, x1, 0f, intArrayOf(cP, cC, cM), null, Shader.TileMode.CLAMP); cv.drawRoundRect(x0, ry - 2 * d, tx0, ry + 2 * d, 2 * d, 2 * d, p); p.shader = null
    if (today.isAfter(s0.minusDays(1)) && today.isBefore(s1)) { p.color = ok; cv.drawRect(tx0 - d, ry - 14 * d, tx0 + d, ry + 14 * d, p); txt("Today", tx0, ry + 28 * d, 9 * d, ok, bold, Paint.Align.CENTER) }
    EVENTS.forEach { e ->
     val ex = xo(e.d); val past = e.d.isBefore(today); val nxt = e === nx
     p.style = Paint.Style.FILL; p.color = bg
     if (e.full) { cv.save(); cv.translate(ex, ry); cv.rotate(45f); val q = 5 * d; cv.drawRoundRect(-q, -q, q, q, 2 * d, 2 * d, p); p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = if (nxt) cM else tx; cv.drawRoundRect(-q, -q, q, q, 2 * d, 2 * d, p)
      if (past) { p.style = Paint.Style.FILL; cv.drawRoundRect(-q, -q, q, q, 2 * d, 2 * d, p) }; cv.restore() }
     else { cv.drawCircle(ex, ry, 6 * d, p); p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = if (nxt) cM else tx; cv.drawCircle(ex, ry, 6 * d, p)
      if (past) { p.style = Paint.Style.FILL; cv.drawCircle(ex, ry, 6 * d, p) } }
     if (nxt) { p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = cM; p.alpha = 70; cv.drawCircle(ex, ry, 11 * d, p); p.alpha = 255; p.style = Paint.Style.FILL
      txt("${e.label} · ${e.d.format(DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH))}", ex.coerceIn(pad + 30 * d, w - pad - 30 * d), ry - 26 * d, 10 * d, tx, bold, Paint.Align.CENTER) }
     else if (!e.full) txt(e.label, ex, ry - 14 * d, 9 * d, tx, bold, Paint.Align.CENTER)
    }
   }
   txt(if (total > 0) "$keys of $total topics studied" else "Open the app and tick topics to track progress", pad, h - pad - 14 * d, 11 * d, mu, med)
   p.color = s2; cv.drawRoundRect(pad, h - pad - 6 * d, pad + iw, h - pad, 3 * d, 3 * d, p)
   if (total > 0) { p.color = ok; cv.drawRoundRect(pad, h - pad - 6 * d, pad + iw * (keys.toFloat() / total).coerceAtMost(1f), h - pad, 3 * d, 3 * d, p) }
   return bmp
  }
 }
}
