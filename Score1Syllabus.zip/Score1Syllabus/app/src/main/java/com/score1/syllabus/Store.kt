package com.score1.syllabus
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
class Res(val id: String, val p: Int, val c: Int, val m: Int, val mx: Int, val rank: Int, val note: String) {
 val total get() = p + c + m
 val pct get() = if (mx > 0) total * 100f / mx else 0f
 fun subPct(i: Int) = listOf(p, c, m)[i] * 300f / maxOf(mx, 1)
}
class Store(private val c: Context) : SQLiteOpenHelper(c, "score1.db", null, 2) {
 override fun onCreate(d: SQLiteDatabase) { d.execSQL("CREATE TABLE done(k TEXT PRIMARY KEY)"); extra(d) }
 private fun extra(d: SQLiteDatabase) { d.execSQL("CREATE TABLE IF NOT EXISTS res(id TEXT PRIMARY KEY,p INT,c INT,m INT,mx INT,rank INT,note TEXT)"); d.execSQL("CREATE TABLE IF NOT EXISTS weak(k TEXT PRIMARY KEY)") }
 override fun onUpgrade(d: SQLiteDatabase, a: Int, b: Int) { extra(d) }
 private fun keys(t: String): Set<String> { val s = mutableSetOf<String>(); readableDatabase.rawQuery("SELECT k FROM $t", null).use { while (it.moveToNext()) s.add(it.getString(0)) }; return s }
 fun all(): Set<String> = keys("done")
 fun weak(): Set<String> = keys("weak")
 fun set(k: String, on: Boolean) { if (on) writableDatabase.execSQL("INSERT OR IGNORE INTO done(k) VALUES(?)", arrayOf(k)) else writableDatabase.execSQL("DELETE FROM done WHERE k=?", arrayOf(k)) }
 fun setWeak(k: String, on: Boolean) { if (on) writableDatabase.execSQL("INSERT OR IGNORE INTO weak(k) VALUES(?)", arrayOf(k)) else writableDatabase.execSQL("DELETE FROM weak WHERE k=?", arrayOf(k)) }
 fun results(): List<Res> { val l = mutableListOf<Res>(); readableDatabase.rawQuery("SELECT id,p,c,m,mx,rank,note FROM res", null).use { while (it.moveToNext()) l.add(Res(it.getString(0), it.getInt(1), it.getInt(2), it.getInt(3), it.getInt(4), it.getInt(5), it.getString(6) ?: "")) }; return l }
 fun putRes(r: Res) { writableDatabase.execSQL("INSERT OR REPLACE INTO res VALUES(?,?,?,?,?,?,?)", arrayOf(r.id, r.p, r.c, r.m, r.mx, r.rank, r.note)) }
 fun delRes(id: String) { writableDatabase.execSQL("DELETE FROM res WHERE id=?", arrayOf(id)) }
 fun replace(keys: Collection<String>) = restoreAll(keys, weak(), results())
 fun restoreAll(done: Collection<String>, weak: Collection<String>, res: Collection<Res>) {
  val d = writableDatabase; d.beginTransaction()
  try {
   d.execSQL("DELETE FROM done"); d.execSQL("DELETE FROM weak"); d.execSQL("DELETE FROM res")
   done.forEach { d.execSQL("INSERT OR IGNORE INTO done(k) VALUES(?)", arrayOf(it)) }; weak.forEach { d.execSQL("INSERT OR IGNORE INTO weak(k) VALUES(?)", arrayOf(it)) }
   res.forEach { r -> d.execSQL("INSERT OR REPLACE INTO res VALUES(?,?,?,?,?,?,?)", arrayOf(r.id, r.p, r.c, r.m, r.mx, r.rank, r.note)) }
   d.setTransactionSuccessful()
  } finally { d.endTransaction() }
 }
 fun mirror(keys: Set<String>) { c.getSharedPreferences("s1", 0).edit().putString("keys", JSONArray(keys.toList()).toString()).putInt("total", TOTAL).apply() }
}
