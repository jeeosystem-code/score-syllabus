package com.score1.syllabus
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
class Store(private val c: Context) : SQLiteOpenHelper(c, "score1.db", null, 1) {
 override fun onCreate(d: SQLiteDatabase) { d.execSQL("CREATE TABLE done(k TEXT PRIMARY KEY)") }
 override fun onUpgrade(d: SQLiteDatabase, a: Int, b: Int) {}
 fun all(): Set<String> { val s = mutableSetOf<String>(); readableDatabase.rawQuery("SELECT k FROM done", null).use { while (it.moveToNext()) s.add(it.getString(0)) }; return s }
 fun set(k: String, on: Boolean) { if (on) writableDatabase.execSQL("INSERT OR IGNORE INTO done(k) VALUES(?)", arrayOf(k)) else writableDatabase.execSQL("DELETE FROM done WHERE k=?", arrayOf(k)) }
 fun replace(keys: Collection<String>) { val d = writableDatabase; d.beginTransaction(); try { d.execSQL("DELETE FROM done"); keys.forEach { d.execSQL("INSERT OR IGNORE INTO done(k) VALUES(?)", arrayOf(it)) }; d.setTransactionSuccessful() } finally { d.endTransaction() } }
 fun mirror(keys: Set<String>) { c.getSharedPreferences("s1", 0).edit().putString("keys", JSONArray(keys.toList()).toString()).putInt("total", TOTAL).apply() }
}
