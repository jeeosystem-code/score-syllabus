@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
package com.score1.syllabus
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as DTS
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

val DMY: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
class CalReq(val title: String, val init: String?, val onPick: (String?) -> Unit)
fun nextId(c: Config, full: Boolean) = (c.tests.filter { it.full == full }.maxOfOrNull { it.id } ?: 0) + 1
fun newTest(c: Config) = TestCfg(nextId(c, false), "Test ${c.tests.size + 1}", LocalDate.now().toString(), false, listOf(Paper("Paper 1", 100)), "", "", listOf("", "", ""))
fun DrawScope.icChev(c: Color, left: Boolean) { val sw = 2.dp.toPx(); val w = size.width; val h = size.height; val a = if (left) .62f else .38f; val b = if (left) .38f else .62f
 drawLine(c, Offset(w * a, h * .25f), Offset(w * b, h * .5f), sw, StrokeCap.Round); drawLine(c, Offset(w * b, h * .5f), Offset(w * a, h * .75f), sw, StrokeCap.Round) }

// ---------- date pickers ----------
@Composable fun ExamPick(p: Pal, st: UiState, idx: Int) {
 val ex = Cfg.allExams().getOrNull(idx) ?: return
 if (ex.days.isNotEmpty()) DaysDialog(p, st, idx, ex) else CalDialog(p, st, CalReq(ex.name.ifEmpty { "Exam" } + " date", ex.date) { iso -> st.setExamDate(idx, iso) }) { st.examPick = null }
}
@Composable fun DaysDialog(p: Pal, st: UiState, idx: Int, ex: ExamCfg) {
 val days = ex.days.mapNotNull { pd(it) }; var sel by remember { mutableStateOf(pd(ex.date)) }; val shape = RoundedCornerShape(18.dp); val rs = RoundedCornerShape(14.dp)
 Dialog(onDismissRequest = { st.examPick = null }) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
   Tx(ex.name.ifEmpty { "Exam" } + " date", p.tx, 22f, FontWeight.ExtraBold, ls = -.4f, m = Modifier.padding(bottom = 4.dp))
   days.forEach { date ->
    val on = sel == date; val left = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
    val bgc by animateColorAsState(if (on) p.M.copy(alpha = .14f) else p.bg, tween(250), label = "jb"); val bc by animateColorAsState(if (on) p.M else p.ln, tween(250), label = "jc")
    val sc by animateFloatAsState(if (on) 1.02f else 1f, spring(.5f, 400f), label = "js"); val ck by animateFloatAsState(if (on) 1f else 0f, tween(220), label = "jk")
    Row(Modifier.fillMaxWidth().graphicsLayer { scaleX = sc; scaleY = sc }.clip(rs).background(bgc).border(if (on) 2.dp else 1.dp, bc, rs).clickable { sel = date; st.tick() }.padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
     Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("${date.dayOfMonth}", p.tx, 26f, FontWeight.ExtraBold, ls = -.6f); Tx(date.month.getDisplayName(DTS.SHORT, Locale.ENGLISH), p.mu, 11f) }
     Column(Modifier.weight(1f)) { Tx(date.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH), p.tx, 16f, FontWeight.SemiBold); Tx(if (left < 0) "passed" else if (left == 0) "today" else "in $left days", p.mu, 12f) }
     Box(Modifier.size(24.dp).clip(CircleShape).border(2.dp, if (on) p.M else p.ln, CircleShape).background(p.M.copy(alpha = ck.coerceIn(0f, 1f))), Alignment.Center) {
      Canvas(Modifier.size(12.dp)) { val w = size.width; val h = size.height; val ca = p.bg.copy(alpha = ck.coerceIn(0f, 1f)); drawLine(ca, Offset(w * .1f, h * .55f), Offset(w * .4f, h * .85f), 2.dp.toPx(), StrokeCap.Round); drawLine(ca, Offset(w * .4f, h * .85f), Offset(w * .9f, h * .15f), 2.dp.toPx(), StrokeCap.Round) }
     }
    }
   }
   FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Save", p.ok, sel != null) { st.setExamDate(idx, sel?.toString()); st.examPick = null }
    if (ex.date != null) Pill(p, "Clear", BAD) { st.setExamDate(idx, null); st.examPick = null }
    Pill(p, "Cancel") { st.examPick = null }
   }
  }
 }
}
@Composable fun CalDialog(p: Pal, st: UiState, r: CalReq, onClose: () -> Unit) {
 val init = pd(r.init); var ym by remember { mutableStateOf(YearMonth.from(init ?: LocalDate.now())) }; var sel by remember { mutableStateOf(init) }
 val today = LocalDate.now(); val shape = RoundedCornerShape(18.dp); val lead = ym.atDay(1).dayOfWeek.value % 7; val len = ym.lengthOfMonth()
 Dialog(onDismissRequest = onClose) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
   Tx(r.title, p.tx, 22f, FontWeight.ExtraBold, ls = -.4f)
   Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
    RoundBtn(p, false, p.tx, 0, { ym = ym.minusMonths(1); st.tick() }) { c -> icChev(c, true) }
    Tx(ym.month.getDisplayName(DTS.FULL, Locale.ENGLISH) + " " + ym.year, p.tx, 17f, FontWeight.SemiBold)
    RoundBtn(p, false, p.tx, 0, { ym = ym.plusMonths(1); st.tick() }) { c -> icChev(c, false) }
   }
   Row(Modifier.padding(top = 4.dp)) { listOf("S", "M", "T", "W", "T", "F", "S").forEach { Tx(it, p.mu, 12f, FontWeight.SemiBold, Modifier.weight(1f), align = TextAlign.Center) } }
   (0 until 6).forEach { w ->
    Row { (0 until 7).forEach { col ->
     val day = w * 7 + col - lead + 1
     Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), Alignment.Center) {
      if (day in 1..len) {
       val date = ym.atDay(day); val on = sel == date
       val bgc by animateColorAsState(if (on) p.M else Color.Transparent, tween(200), label = "cb"); val fg by animateColorAsState(if (on) p.bg else p.tx, tween(200), label = "cf")
       Box(Modifier.fillMaxSize().clip(CircleShape).background(bgc).then(if (date == today && !on) Modifier.border(1.dp, p.M, CircleShape) else Modifier).clickable { sel = date; st.tick() }, Alignment.Center) { Tx("$day", fg, 14f, FontWeight.SemiBold) }
      }
     }
    } }
   }
   FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Save", p.ok, sel != null) { r.onPick(sel?.toString()); onClose() }
    if (r.init != null) Pill(p, "Clear", BAD) { r.onPick(null); onClose() }
    Pill(p, "Cancel") { onClose() }
   }
  }
 }
}

// ---------- builder ----------
@Composable fun TextBox(p: Pal, label: String, v: String, m: Modifier = Modifier, num: Boolean = false, lines: Int = 1, on: (String) -> Unit) {
 val shape = RoundedCornerShape(12.dp)
 Column(m.padding(top = 10.dp)) {
  Tx(label, p.mu, 12f, FontWeight.SemiBold)
  Box(Modifier.padding(top = 4.dp).fillMaxWidth().clip(shape).background(p.bg).border(1.dp, p.ln, shape).padding(horizontal = 12.dp, vertical = 10.dp)) {
   BasicTextField(v, on, Modifier.fillMaxWidth(), singleLine = lines == 1, minLines = lines, textStyle = TextStyle(color = p.tx, fontSize = 15.sp, fontFamily = Body), cursorBrush = SolidColor(p.M), keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text))
  }
 }
}
@Composable fun LogoRow(p: Pal, sel: Int, on: (Int) -> Unit) {
 Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
  LOGOS.forEachIndexed { i, res ->
   val chosen = sel == i + 1; val sc by animateFloatAsState(if (chosen) 1.08f else 1f, spring(.6f, 400f), label = "lg"); val rs = RoundedCornerShape(18.dp)
   Box(Modifier.size(64.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(rs).background(Color(android.graphics.Color.parseColor(LOGO_BG[i]))).border(if (chosen) 3.dp else 1.dp, if (chosen) p.M else p.ln, rs).clickable { on(i + 1) }) { Image(painterResource(res), null, Modifier.fillMaxSize()) }
  }
 }
}
@Composable fun ExamEditor(p: Pal, st: UiState, e: ExamCfg, change: (ExamCfg) -> Unit, del: () -> Unit) {
 Column {
  TextBox(p, "Exam name", e.name) { v -> change(e.copy(name = v)) }
  Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
   Pill(p, pd(e.date)?.format(DMY) ?: "Pick date", p.M, e.date != null) { st.cal = CalReq(e.name.ifEmpty { "Exam" } + " date", e.date) { iso -> change(e.copy(date = iso)) } }
   Pill(p, "Remove", BAD) { del() }
  }
 }
}
@Composable fun BuilderScreen(p: Pal, st: UiState) {
 val d = st.draft ?: return; val et = st.editTest
 BackHandler(true) { if (st.editTest != null) st.editTest = null else st.builderOpen = false }
 Box(Modifier.fillMaxSize().background(p.bg)) { if (et != null && et in d.tests.indices) TestEditor(p, st, et) else BuilderHome(p, st) }
}
@Composable fun BuilderHome(p: Pal, st: UiState) {
 val ctx = LocalContext.current; val d = st.draft!!; var confirm by remember { mutableStateOf(false) }
 fun up(f: (Config) -> Config) { st.draft = f(st.draft!!) }
 fun apply() { Cfg.applyCfg(st.prefs, st.draft!!); Widgets.refresh(ctx); st.builderOpen = false; st.editTest = null; st.tab = 0; st.exportMsg = ""; st.exportUri = null }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
  item { Row(Modifier.padding(start = PadH, end = PadH, top = 24.dp, bottom = 14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
   Tx("Builder", p.tx, 32f, FontWeight.ExtraBold, ls = -.8f)
   Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill(p, "Apply", p.ok, true) { apply() }; Pill(p, "Close") { st.builderOpen = false } }
  } }
  item { Card(p) {
   Tx("App", p.tx, 18f, FontWeight.Bold)
   TextBox(p, "App name", d.appName) { v -> up { it.copy(appName = v) } }
   TextBox(p, "Subtitle", d.brand) { v -> up { it.copy(brand = v) } }
   Tx("Logo", p.mu, 12f, FontWeight.SemiBold, Modifier.padding(top = 12.dp)); LogoRow(p, d.logo) { i -> up { it.copy(logo = i) } }
  } }
  item { Card(p) {
   Tx("Subjects", p.tx, 18f, FontWeight.Bold)
   d.subjects.forEachIndexed { i, s -> TextBox(p, "Subject ${i + 1}", s) { v -> up { c -> c.copy(subjects = c.subjects.mapIndexed { k, x -> if (k == i) v else x }) } } }
  } }
  item { Card(p) {
   Tx("Target exam", p.tx, 18f, FontWeight.Bold)
   val t = d.target
   if (t == null) Pill(p, "Add target exam", p.tx, false, Modifier.padding(top = 10.dp)) { up { it.copy(target = ExamCfg("Target exam", null, null, null, emptyList())) } }
   else ExamEditor(p, st, t, { n -> up { it.copy(target = n) } }, { up { it.copy(target = null) } })
  } }
  item { Card(p) {
   Tx("Other exams", p.tx, 18f, FontWeight.Bold)
   d.exams.forEachIndexed { i, e -> Box(Modifier.padding(top = 6.dp)) { ExamEditor(p, st, e, { n -> up { c -> c.copy(exams = c.exams.mapIndexed { k, x -> if (k == i) n else x }) } }, { up { c -> c.copy(exams = c.exams.filterIndexed { k, _ -> k != i }) } }) } }
   Pill(p, "Add exam", p.tx, false, Modifier.padding(top = 12.dp)) { up { it.copy(exams = it.exams + ExamCfg("Exam ${it.exams.size + 1}", null, null, null, emptyList())) } }
  } }
  item { Card(p) {
   Tx("Tests", p.tx, 18f, FontWeight.Bold)
   d.tests.forEachIndexed { i, t -> TestRow(p, st, i, t) }
   Pill(p, "Add test", p.tx, false, Modifier.padding(top = 12.dp)) { val c = st.draft!!; st.draft = c.copy(tests = c.tests + newTest(c)); st.editTest = c.tests.size }
  } }
  item { Card(p) {
   Tx("Your data", p.tx, 18f, FontWeight.Bold)
   FlowRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Load ALLEN sample") { st.draft = Cfg.preset(ctx) }
    Pill(p, "Start blank") { st.draft = Cfg.blank() }
    Pill(p, if (confirm) "Tap again to reset" else "Reset progress", BAD, confirm) { if (confirm) { st.resetProgress(); confirm = false } else confirm = true }
   }
  } }
  item { Card(p) {
   Tx("Your APK", p.tx, 18f, FontWeight.Bold)
   Tx("Creates a project zip with your app, your data and this builder. Upload the zip to GitHub to build the APK.", p.mu, 13f, m = Modifier.padding(top = 4.dp))
   FlowRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Include my progress", p.P, st.inclProgress) { st.inclProgress = !st.inclProgress }
    Pill(p, "Create APK project", p.ok, true) { val r = Exporter.make(ctx, st.draft!!, if (st.inclProgress) st.exportProgress() else null); st.exportMsg = r.first; st.exportUri = r.second }
    if (st.exportUri != null && Build.VERSION.SDK_INT >= 29) Pill(p, "Share") { val u = st.exportUri; if (u != null) { val i = Intent(Intent.ACTION_SEND).apply { type = "application/zip"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }; ctx.startActivity(Intent.createChooser(i, "Share project")) } }
   }
   if (st.exportMsg.isNotEmpty()) Tx(st.exportMsg, p.ok, 13f, m = Modifier.padding(top = 8.dp))
  } }
 }
}
@Composable fun TestRow(p: Pal, st: UiState, i: Int, t: TestCfg) {
 val shape = RoundedCornerShape(14.dp); val live = Cfg.cur.tests.any { it.id == t.id && it.full == t.full }
 Column(Modifier.padding(top = 10.dp).fillMaxWidth().clip(shape).background(p.bg).clickable { st.editTest = i }.padding(12.dp)) {
  Tx(t.name.ifEmpty { "Untitled" }, p.tx, 15f, FontWeight.SemiBold)
  Tx((pd(t.date)?.format(DMY) ?: "No date") + " · " + (if (t.full) "Full test" else "Syllabus test") + " · " + t.papers.size + (if (t.papers.size == 1) " paper" else " papers"), p.mu, 12f)
  if (live) FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
   t.papers.forEachIndexed { pi, pp -> Pill(p, "Log " + pp.name, p.P) { st.editing = (if (t.full) "f" else "pt") + t.id + suf(pi) } }
  }
 }
}
@Composable fun TestEditor(p: Pal, st: UiState, idx: Int) {
 val d = st.draft!!; val t = d.tests[idx]
 fun upT(f: (TestCfg) -> TestCfg) { val c = st.draft!!; st.draft = c.copy(tests = c.tests.mapIndexed { i, x -> if (i == idx) f(x) else x }) }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
  item { Row(Modifier.padding(start = PadH, end = PadH, top = 24.dp, bottom = 14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
   Tx("Edit test", p.tx, 28f, FontWeight.ExtraBold, ls = -.6f)
   Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill(p, "Done", p.ok, true) { st.editTest = null }; Pill(p, "Delete", BAD) { val c = st.draft!!; st.draft = c.copy(tests = c.tests.filterIndexed { i, _ -> i != idx }); st.editTest = null } }
  } }
  item { Card(p) {
   TextBox(p, "Test name", t.name) { v -> upT { it.copy(name = v) } }
   Row(Modifier.padding(top = 10.dp)) { Pill(p, pd(t.date)?.format(DMY) ?: "Pick date", p.M, true) { st.cal = CalReq("Test date", t.date) { iso -> if (iso != null) upT { it.copy(date = iso) } } } }
   Seg2(p, listOf("Syllabus test", "Full test"), if (t.full) 1 else 0, Modifier.padding(top = 12.dp)) { k -> val full = k == 1; if (full != t.full) { val c = st.draft!!; upT { it.copy(full = full, id = nextId(c, full), tag = if (full) "Full syllabus" else "") } } }
   TextBox(p, "Time (optional)", t.time) { v -> upT { it.copy(time = v) } }
  } }
  item { Card(p) {
   Tx("Papers", p.tx, 18f, FontWeight.Bold)
   t.papers.forEachIndexed { pi, pp ->
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
     TextBox(p, "Paper name", pp.name, Modifier.weight(1f)) { v -> upT { x -> x.copy(papers = x.papers.mapIndexed { k, y -> if (k == pi) y.copy(name = v) else y }) } }
     TextBox(p, "Max marks", pp.max.toString(), Modifier.width(96.dp), num = true) { v -> val m = v.filter { ch -> ch.isDigit() }.take(4).toIntOrNull() ?: 0; upT { x -> x.copy(papers = x.papers.mapIndexed { k, y -> if (k == pi) y.copy(max = m) else y }) } }
     if (t.papers.size > 1) Pill(p, "×", BAD) { upT { x -> x.copy(papers = x.papers.filterIndexed { k, _ -> k != pi }) } }
    }
   }
   Pill(p, "Add paper", p.tx, false, Modifier.padding(top = 12.dp)) { upT { x -> x.copy(papers = x.papers + Paper("Paper ${x.papers.size + 1}", 100)) } }
  } }
  if (!t.full) item { Card(p) {
   Tx("Syllabus topics", p.tx, 18f, FontWeight.Bold)
   (0..2).forEach { s -> TextBox(p, d.subjects.getOrElse(s) { "Subject" }, t.topics.getOrElse(s) { "" }, lines = 6) { v -> upT { x -> x.copy(topics = (0..2).map { k -> if (k == s) v else x.topics.getOrElse(k) { "" } }) } } }
   Tx("One topic per line. Start a line with # to name a group.", p.mu, 12f, m = Modifier.padding(top = 8.dp))
  } }
 }
}

// ---------- APK project export ----------
object Exporter {
 private const val ROOT = "Score1Syllabus"
 private fun xml(s: String): String { val e = s.replace("&", "&amp;").replace("<", "&lt;").replace("'", "\\'").replace("\"", "\\\""); return if (e.startsWith("@") || e.startsWith("?")) "\\" + e else e }
 fun make(c: Context, cfg: Config, progress: JSONObject?): Pair<String, Uri?> {
  val tpl = try { c.assets.open("template.zip").use { it.readBytes() } } catch (e: Exception) { return "This build has no project template." to null }
  val files = LinkedHashMap<String, ByteArray>()
  ZipInputStream(ByteArrayInputStream(tpl)).use { zi -> var e = zi.nextEntry; while (e != null) { if (!e.isDirectory) files[e.name] = zi.readBytes(); e = zi.nextEntry } }
  val slug = cfg.appName.lowercase().filter { it.isLetterOrDigit() && it.code < 128 }.ifEmpty { "tracker" }
  val appId = "com.tracker." + (if (slug[0].isDigit()) "t$slug" else slug)
  val base = "$ROOT/app/src/main/"
  fun edit(path: String, f: (String) -> String) { val k = base + path; val v = files[k]; if (v != null) files[k] = f(String(v, Charsets.UTF_8)).toByteArray(Charsets.UTF_8) }
  val appXml = "<string name=\"app_name\">" + xml(cfg.appName.ifEmpty { "My Tracker" }) + "</string>"
  edit("res/values/strings.xml") { it.replace(Regex("<string name=\"app_name\">.*?</string>")) { appXml } }
  val gk = "$ROOT/app/build.gradle.kts"; val gv = files[gk]
  if (gv != null) files[gk] = String(gv, Charsets.UTF_8).replace("applicationId=\"com.score1.syllabus\"", "applicationId=\"$appId\"").toByteArray(Charsets.UTF_8)
  val n = cfg.logo.coerceIn(1, 6); val logo = files[base + "res/drawable/logo_$n.xml"]
  if (logo != null) { files[base + "res/drawable/ic_fg.xml"] = logo; files[base + "res/drawable/ic_mono.xml"] = String(logo, Charsets.UTF_8).replace(Regex("#[0-9A-Fa-f]{6}(?![0-9A-Fa-f])"), "#000000").toByteArray(Charsets.UTF_8) }
  edit("res/values/colors.xml") { it.replace(Regex("<color name=\"ink\">#[0-9A-Fa-f]+</color>"), "<color name=\"ink\">" + LOGO_BG[n - 1] + "</color>") }
  val tj = JSONObject().put("config", cfg.toJson()); if (progress != null) tj.put("progress", progress)
  files[base + "assets/tracker.json"] = tj.toString().toByteArray(Charsets.UTF_8)
  files[base + "assets/template.zip"] = tpl
  val out = ByteArrayOutputStream()
  ZipOutputStream(out).use { z -> for ((k, v) in files) { z.putNextEntry(ZipEntry(k)); z.write(v); z.closeEntry() } }
  return save(c, "$slug-tracker.zip", out.toByteArray())
 }
 private fun save(c: Context, name: String, bytes: ByteArray): Pair<String, Uri?> {
  return try {
   if (Build.VERSION.SDK_INT >= 29) {
    val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, "application/zip"); put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS) }
    val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
    if (uri == null) "Could not save the file." to null else { c.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }; "Saved in Downloads as $name" to uri }
   } else { val f = java.io.File(c.getExternalFilesDir(null), name); f.writeBytes(bytes); "Saved to " + f.absolutePath to Uri.fromFile(f) }
  } catch (e: Exception) { "Could not save the file." to null }
 }
}
