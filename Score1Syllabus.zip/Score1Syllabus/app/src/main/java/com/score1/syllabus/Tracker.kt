@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
package com.score1.syllabus
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.TextStyle as DTS
import java.time.temporal.ChronoUnit
import java.util.Locale

val BAD = Color(0xFFFF6B6B)
fun evId(e: Ev) = (if (e.full) "f" else "pt") + e.label.filter { it.isDigit() }
fun r0(f: Float) = Math.round(f)

@Composable fun BottomBar(p: Pal, st: UiState) {
 val labels = listOf("Syllabus", "Tests", "Insights")
 Column(Modifier.fillMaxWidth().background(p.s1)) {
  Box(Modifier.fillMaxWidth().height(1.dp).background(p.ln))
  BoxWithConstraints(Modifier.fillMaxWidth().navigationBarsPadding()) {
   val w = maxWidth / 3; val off by animateDpAsState(w * st.tab, spring(0.7f, 400f), label = "tb")
   Box(Modifier.offset(x = off + w / 2 - 18.dp).width(36.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Brush.horizontalGradient(listOf(p.P, p.C, p.M))))
   Row {
    labels.forEachIndexed { i, l ->
     val c by animateColorAsState(if (st.tab == i) p.tx else p.mu, tween(200), label = "tc")
     Box(Modifier.weight(1f).clickable { st.tab = i; st.tick() }.padding(vertical = 14.dp), Alignment.Center) { Tx(l, c, 14f, if (st.tab == i) FontWeight.Bold else FontWeight.Medium) }
    }
   }
  }
 }
}

@Composable fun TestsTab(p: Pal, st: UiState) {
 val got = EVENTS.count { st.results.containsKey(evId(it)) }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
  item { Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp)) { Tx("Test tracker", p.tx, 32f, FontWeight.ExtraBold, ls = -.8f); Tx("$got of ${EVENTS.size} results logged. Tap a test to add or edit its score.", p.mu, 14f, m = Modifier.padding(top = 4.dp)) } }
  itemsIndexed(EVENTS) { i, e -> ResultCard(i, e, p, st) }
 }
}
@Composable fun ResultCard(i: Int, e: Ev, p: Pal, st: UiState) {
 val id = evId(e); val r = st.results[id]; val n = ChronoUnit.DAYS.between(LocalDate.now(), e.d).toInt()
 val prev = EVENTS.take(i).mapNotNull { st.results[evId(it)] }.lastOrNull(); val shape = RoundedCornerShape(18.dp)
 val ready = if (e.full) overallPct(st.mode, st.done) else (TESTS.firstOrNull { "pt${it.id}" == id }?.let { testPct(it, st.mode, st.done) } ?: 0f)
 Row(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp).fillMaxWidth().clip(shape).background(p.s1).border(1.dp, p.ln, shape).clickable { st.editing = id }.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
  Column(Modifier.width(48.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("${e.d.dayOfMonth}", p.tx, 30f, FontWeight.ExtraBold, ls = -1f); Tx(e.d.month.getDisplayName(DTS.SHORT, Locale.ENGLISH), p.mu, 12f) }
  Column(Modifier.weight(1f)) {
   Tx(e.name, p.tx, 18f, FontWeight.Bold); Tx("${e.d.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH)} · ${if (n < 0) "done" else if (n == 0) "today" else "in $n days"}", p.mu, 12f)
   if (r == null) Tx(if (n <= 0) "Add your result" else "Syllabus ready: ${r0(ready * 100)}%", if (n <= 0) p.M else p.mu, 13f, FontWeight.SemiBold, Modifier.padding(top = 8.dp))
   else Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
    (0..2).forEach { s -> val a by animateFloatAsState((r.subPct(s) / 100f).coerceIn(0f, 1f), tween(600), label = "rs"); Box(Modifier.width(38.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.sub(s))) } }
   }
  }
  if (r != null) Column(horizontalAlignment = Alignment.End) {
   Tx("${r.total}", p.tx, 26f, FontWeight.ExtraBold, ls = -.6f); Tx("/ ${r.mx} · ${r0(r.pct)}%", p.mu, 12f)
   if (r.rank > 0) Tx("Rank ${r.rank}", p.mu, 12f)
   if (prev != null) { val d = r.pct - prev.pct; Tx((if (d >= 0) "▲ " else "▼ ") + Math.abs(r0(d)) + " pts", if (d >= 0) p.ok else BAD, 12f, FontWeight.Bold) }
  }
 }
}

@Composable fun Card(p: Pal, m: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
 val shape = RoundedCornerShape(18.dp)
 Column(m.padding(horizontal = 16.dp).padding(bottom = 12.dp).fillMaxWidth().clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(16.dp), content = content)
}
@Composable fun InsightsTab(p: Pal, st: UiState) {
 val got = EVENTS.mapNotNull { st.results[evId(it)] }
 val avg = if (got.isEmpty()) 0f else got.map { it.pct }.average().toFloat(); val best = got.maxByOrNull { it.pct }
 val subAvg = (0..2).map { s -> if (got.isEmpty()) 0f else got.map { it.subPct(s) }.average().toFloat() }
 val gap = st.goal - avg
 val note = if (got.isEmpty()) "Log your first test result to unlock trends and subject insights." else {
  val wk = subAvg.indices.minByOrNull { subAvg[it] }!!; val sk = subAvg.indices.maxByOrNull { subAvg[it] }!!
  val a = if (wk == sk) "" else "${SN[wk]} is your weakest subject at ${r0(subAvg[wk])}%, while ${SN[sk]} leads at ${r0(subAvg[sk])}%. Flag its topics for revision to lift your score fastest. "
  val b = if (got.size > 1) "Your latest score is ${if (got.last().pct >= got[got.size - 2].pct) "up" else "down"} ${Math.abs(r0(got.last().pct - got[got.size - 2].pct))} points on the previous test. " else ""
  a + b + (if (gap > 0) "You are ${r0(gap)} points below your ${st.goal}% target on average." else "You are above your ${st.goal}% target on average. Keep it steady.")
 }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
  item { Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp)) { Tx("Insights", p.tx, 32f, FontWeight.ExtraBold, ls = -.8f); Tx("Trends from the results you log in the Tests tab.", p.mu, 14f, m = Modifier.padding(top = 4.dp)) } }
  item { Row(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
   Stat(p, "${got.size}/${EVENTS.size}", "tests taken", Modifier.weight(1f)); Stat(p, "${r0(avg)}%", "average", Modifier.weight(1f)); Stat(p, best?.let { "${r0(it.pct)}%" } ?: "–", "best score", Modifier.weight(1f)) } }
  item { Card(p) {
   Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
    Column { Tx("Target score", p.mu, 13f); Tx("${st.goal}%", p.tx, 28f, FontWeight.ExtraBold, ls = -.6f) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill(p, "−5") { st.changeGoal(st.goal - 5); st.tick() }; Pill(p, "+5") { st.changeGoal(st.goal + 5); st.tick() } }
   }
   val a by animateFloatAsState((avg / st.goal).coerceIn(0f, 1f), tween(700), label = "g")
   Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.ok)) }
  } }
  item { Card(p) {
   Tx("Score trend", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
   Box { Trend(p, got.map { it.pct }, st.goal); Tx("100%", p.mu, 10f, m = Modifier.offset(0.dp, 2.dp)); Tx("50%", p.mu, 10f, m = Modifier.offset(0.dp, 74.dp)); Tx("0%", p.mu, 10f, m = Modifier.offset(0.dp, 146.dp)) }
   Tx("Dashed line is your target.", p.mu, 12f, m = Modifier.padding(top = 6.dp))
  } }
  item { Card(p) {
   Tx("Subject average", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
   (0..2).forEach { s -> val a by animateFloatAsState((subAvg[s] / 100f).coerceIn(0f, 1f), tween(800), label = "sa")
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
     Tx(SN[s], p.sub(s), 13f, FontWeight.SemiBold, Modifier.width(92.dp))
     Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.sub(s))) }
     Tx("${r0(subAvg[s])}%", p.tx, 13f, FontWeight.Bold, Modifier.width(48.dp), align = androidx.compose.ui.text.style.TextAlign.End)
    } }
  } }
  item { Card(p) { Tx("What to do next", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 6.dp)); Tx(note, p.mu, 14f, lh = 20f) } }
 }
}
@Composable fun Trend(p: Pal, pts: List<Float>, goal: Int) {
 var go by remember { mutableStateOf(false) }; LaunchedEffect(pts.size) { go = false; delay(60); go = true }
 val pg by animateFloatAsState(if (go) 1f else 0f, tween(1200, easing = FastOutSlowInEasing), label = "tr")
 Canvas(Modifier.fillMaxWidth().height(160.dp)) {
  val l = 34.dp.toPx(); val w = size.width - l - 10.dp.toPx(); val top = 8.dp.toPx(); val h = size.height - 16.dp.toPx()
  fun y(v: Float) = top + h * (1f - (v / 100f).coerceIn(0f, 1f))
  listOf(0f, 50f, 100f).forEach { drawLine(p.ln, Offset(l, y(it)), Offset(l + w, y(it)), 1.dp.toPx()) }
  drawLine(p.ok, Offset(l, y(goal.toFloat())), Offset(l + w, y(goal.toFloat())), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
  if (pts.isEmpty()) return@Canvas
  val xs = pts.indices.map { if (pts.size == 1) l + w / 2 else l + w * it / (pts.size - 1f) }
  clipRect(0f, 0f, l + (w + 10.dp.toPx()) * pg, size.height) {
   if (pts.size > 1) { val path = Path(); pts.forEachIndexed { i, v -> if (i == 0) path.moveTo(xs[i], y(v)) else path.lineTo(xs[i], y(v)) }
    drawPath(path, Brush.horizontalGradient(listOf(p.P, p.C, p.M), startX = l, endX = l + w), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)) }
   pts.forEachIndexed { i, v -> drawCircle(p.bg, radius = 6.dp.toPx(), center = Offset(xs[i], y(v))); drawCircle(p.M, radius = 6.dp.toPx(), center = Offset(xs[i], y(v)), style = Stroke(2.5.dp.toPx())) }
  }
 }
}

@Composable fun RowScope.Field(p: Pal, label: String, v: String, col: Color, num: Boolean = true, on: (String) -> Unit) {
 val shape = RoundedCornerShape(12.dp)
 Column(Modifier.weight(1f)) {
  Tx(label, col, 12f, FontWeight.SemiBold)
  Box(Modifier.padding(top = 4.dp).fillMaxWidth().clip(shape).background(p.bg).border(1.dp, p.ln, shape).padding(horizontal = 12.dp, vertical = 10.dp)) {
   BasicTextField(v, on, Modifier.fillMaxWidth(), singleLine = true, textStyle = TextStyle(color = p.tx, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = Body), cursorBrush = SolidColor(p.M), keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text))
  }
 }
}
@Composable fun ResultDialog(p: Pal, st: UiState, id: String) {
 val e = EVENTS.first { evId(it) == id }; val old = st.results[id]
 var a by remember { mutableStateOf(old?.p?.toString() ?: "") }; var b by remember { mutableStateOf(old?.c?.toString() ?: "") }; var c by remember { mutableStateOf(old?.m?.toString() ?: "") }
 var mx by remember { mutableStateOf((old?.mx ?: 300).toString()) }; var rk by remember { mutableStateOf(if ((old?.rank ?: 0) > 0) old!!.rank.toString() else "") }; var note by remember { mutableStateOf(old?.note ?: "") }
 val ok = a.toIntOrNull() != null && b.toIntOrNull() != null && c.toIntOrNull() != null && (mx.toIntOrNull() ?: 0) > 0; val shape = RoundedCornerShape(18.dp)
 Dialog(onDismissRequest = { st.editing = null }) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
   Tx("${e.name} result", p.tx, 22f, FontWeight.ExtraBold, ls = -.4f)
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Field(p, "Physics", a, p.P) { a = it }; Field(p, "Chemistry", b, p.C) { b = it }; Field(p, "Maths", c, p.M) { c = it } }
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Field(p, "Max marks", mx, p.tx) { mx = it }; Field(p, "Rank (optional)", rk, p.tx) { rk = it } }
   Row { Field(p, "Note: mistakes, lessons", note, p.tx, false) { note = it } }
   FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Save", p.ok, ok) { if (ok) { st.saveRes(Res(id, a.toInt(), b.toInt(), c.toInt(), mx.toInt(), rk.toIntOrNull() ?: 0, note.trim())); st.editing = null; st.tick() } }
    if (old != null) Pill(p, "Delete", BAD) { st.clearRes(id); st.editing = null }
    Pill(p, "Cancel") { st.editing = null }
   }
  }
 }
}
