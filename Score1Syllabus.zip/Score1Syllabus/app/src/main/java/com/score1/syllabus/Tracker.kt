@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
package com.score1.syllabus
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.TextStyle as DTS
import java.time.temporal.ChronoUnit
import java.util.Locale

val BAD = Color(0xFFFF6B6B)
fun evId(e: Ev) = (if (e.full) "f" else "pt") + e.label.filter { it.isDigit() }
fun r0(f: Float) = Math.round(f)

@Composable fun BottomBar(p: Pal, st: UiState) {
 val labels = listOf("Syllabus", "Tests", "Insights")
 Column(Modifier.fillMaxWidth().background(p.s1)) {
  Box(Modifier.fillMaxWidth().height(1.dp).background(p.ln))
  BoxWithConstraints(Modifier.fillMaxWidth().navigationBarsPadding()) {
   val w = maxWidth / 3; val off by animateDpAsState(w * st.tab, spring(0.7f, 400f), label = "tb")
   Box(Modifier.offset(x = off + w / 2 - 18.dp).width(36.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Brush.horizontalGradient(listOf(p.P, p.C, p.M))))
   Row {
    labels.forEachIndexed { i, l ->
     val c by animateColorAsState(if (st.tab == i) p.tx else p.mu, tween(200), label = "tc")
     Box(Modifier.weight(1f).clickable { st.tab = i; st.tick() }.padding(vertical = 14.dp), Alignment.Center) { Tx(l, c, 14f, if (st.tab == i) FontWeight.Bold else FontWeight.Medium) }
    }
   }
  }
 }
}

@Composable fun TestsTab(p: Pal, st: UiState) {
 val got = EVENTS.count { st.results.containsKey(evId(it)) }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
  item { Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp)) { Tx("Test tracker", p.tx, 32f, FontWeight.ExtraBold, ls = -.8f); Tx("${st.results.size} of 17 papers logged", p.mu, 14f, m = Modifier.padding(top = 4.dp)) } }
  itemsIndexed(EVENTS) { i, e -> ResultCard(i, e, p, st) }
 }
}
fun advId(e: Ev) = evId(e) + "a"
@Composable fun ResultCard(i: Int, e: Ev, p: Pal, st: UiState) {
 val n = ChronoUnit.DAYS.between(LocalDate.now(), e.d).toInt()
 val ready = if (e.full) overallPct(st.mode, st.done) else (TESTS.firstOrNull { "pt${it.id}" == evId(e) }?.let { testPct(it, st.mode, st.done) } ?: 0f)
 Card(p) {
  Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
   Column(Modifier.width(48.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("${e.d.dayOfMonth}", p.tx, 30f, FontWeight.ExtraBold, ls = -1f); Tx(e.d.month.getDisplayName(DTS.SHORT, Locale.ENGLISH), p.mu, 12f) }
   Column(Modifier.weight(1f)) {
    Tx(e.name, p.tx, 18f, FontWeight.Bold); Tx("${e.d.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH)} · ${if (n < 0) "done" else if (n == 0) "today" else "in $n days"}", p.mu, 12f)
    if (n > 0) Tx("Syllabus ready: ${r0(ready * 100)}%", p.mu, 12f)
   }
  }
  if (e.full) PaperRow("Full syllabus · one paper", evId(e), e, i, false, p, st)
  else { PaperRow("JEE Main paper", evId(e), e, i, false, p, st); PaperRow("JEE Advanced paper", advId(e), e, i, true, p, st) }
 }
}
@Composable fun PaperRow(label: String, rid: String, e: Ev, i: Int, adv: Boolean, p: Pal, st: UiState) {
 val r = st.results[rid]; val n = ChronoUnit.DAYS.between(LocalDate.now(), e.d).toInt()
 val prev = EVENTS.take(i).mapNotNull { st.results[if (adv) advId(it) else evId(it)] }.lastOrNull()
 Row(Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.bg).clickable { st.editing = rid }.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
  Column(Modifier.weight(1f)) {
   Tx(label, p.tx, 14f, FontWeight.SemiBold)
   if (r == null) Tx(if (n <= 0) "Add result" else "Not taken yet", if (n <= 0) p.M else p.mu, 12f, m = Modifier.padding(top = 2.dp))
   else Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
    (0..2).forEach { s -> val a by animateFloatAsState((r.subPct(s) / 100f).coerceIn(0f, 1f), tween(600), label = "rs"); Box(Modifier.width(34.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.sub(s))) } }
   }
  }
  if (r != null) Column(horizontalAlignment = Alignment.End) {
   Tx("${r.total}", p.tx, 22f, FontWeight.ExtraBold, ls = -.5f); Tx("/ ${r.mx} · ${r0(r.pct)}%", p.mu, 11f)
   if (r.rank > 0) Tx("Rank ${r.rank}", p.mu, 11f)
   if (prev != null) { val d = r.pct - prev.pct; Tx((if (d >= 0) "▲ " else "▼ ") + Math.abs(r0(d)) + " pts", if (d >= 0) p.ok else BAD, 11f, FontWeight.Bold) }
  }
 }
}
@Composable fun ThemeIcon(mode: Int, c: Color) {
 Canvas(Modifier.size(22.dp)) {
  val ctr = center; val r = size.minDimension * 0.2f; val sw = 1.8.dp.toPx()
  when (mode) {
   1 -> { drawCircle(c, radius = r, center = ctr); for (k in 0 until 8) { val a = k * Math.PI / 4; val d1 = r + 3.dp.toPx(); val d2 = r + 6.dp.toPx()
    drawLine(c, Offset(ctr.x + (Math.cos(a) * d1).toFloat(), ctr.y + (Math.sin(a) * d1).toFloat()), Offset(ctr.x + (Math.cos(a) * d2).toFloat(), ctr.y + (Math.sin(a) * d2).toFloat()), sw, StrokeCap.Round) } }
   2 -> { val big = Path().apply { addOval(Rect(ctr, r * 1.7f)) }; val cut = Path().apply { addOval(Rect(Offset(ctr.x + r * 0.8f, ctr.y - r * 0.6f), r * 1.4f)) }; drawPath(Path.combine(PathOperation.Difference, big, cut), c) }
   else -> { val rr = r * 1.6f; drawCircle(c, radius = rr, center = ctr, style = Stroke(sw)); drawArc(c, 90f, 180f, true, Offset(ctr.x - rr, ctr.y - rr), Size(rr * 2, rr * 2)) }
  }
 }
}
@Composable fun Seg2(p: Pal, labels: List<String>, sel: Int, m: Modifier = Modifier, on: (Int) -> Unit) {
 BoxWithConstraints(m.fillMaxWidth().clip(CircleShape).background(p.s2).padding(3.dp)) {
  val wd = maxWidth / labels.size; val off by animateDpAsState(wd * sel, spring(0.7f, 400f), label = "s2")
  Box(Modifier.offset(x = off).size(wd, 34.dp).clip(CircleShape).background(p.tx))
  Row(Modifier.fillMaxWidth()) { labels.forEachIndexed { i, l -> val fg by animateColorAsState(if (sel == i) p.bg else p.tx, tween(250), label = "s2f"); Box(Modifier.weight(1f).height(34.dp).clip(CircleShape).clickable { on(i) }, Alignment.Center) { Tx(l, fg, 14f, FontWeight.SemiBold) } } }
 }
}
fun clampMark(s: String, lim: Float): String { val d = s.filterIndexed { i, ch -> ch.isDigit() || (ch == '-' && i == 0) }; val v = d.toIntOrNull() ?: return d; return if (v > lim) lim.toInt().toString() else if (v < -lim) (-lim).toInt().toString() else d }
val EXAM_DAYS = listOf(22, 23, 24, 28, 29, 30)
@Composable fun JeeDialog(p: Pal, st: UiState) {
 var sel by remember { mutableStateOf(st.jee?.let { LocalDate.parse(it).dayOfMonth }) }; val shape = RoundedCornerShape(18.dp); val rs = RoundedCornerShape(14.dp)
 Dialog(onDismissRequest = { st.jeePicker = false }) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
   Tx("JEE Main exam date", p.tx, 22f, FontWeight.ExtraBold, ls = -.4f, m = Modifier.padding(bottom = 4.dp))
   EXAM_DAYS.forEach { d ->
    val date = LocalDate.of(2027, 1, d); val on = sel == d; val left = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
    val bgc by animateColorAsState(if (on) p.M.copy(alpha = .14f) else p.bg, tween(250), label = "jb"); val bc by animateColorAsState(if (on) p.M else p.ln, tween(250), label = "jc")
    val sc by animateFloatAsState(if (on) 1.02f else 1f, spring(.5f, 400f), label = "js"); val ck by animateFloatAsState(if (on) 1f else 0f, spring(.6f, 400f), label = "jk")
    Row(Modifier.fillMaxWidth().graphicsLayer { scaleX = sc; scaleY = sc }.clip(rs).background(bgc).border(if (on) 2.dp else 1.dp, bc, rs).clickable { sel = d; st.tick() }.padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
     Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) { Tx("$d", p.tx, 26f, FontWeight.ExtraBold, ls = -.6f); Tx("Jan", p.mu, 11f) }
     Column(Modifier.weight(1f)) { Tx(date.dayOfWeek.getDisplayName(DTS.FULL, Locale.ENGLISH), p.tx, 16f, FontWeight.SemiBold); Tx(if (left < 0) "passed" else if (left == 0) "today" else "in $left days", p.mu, 12f) }
     Box(Modifier.size(24.dp).clip(CircleShape).border(2.dp, if (on) p.M else p.ln, CircleShape).background(p.M.copy(alpha = ck)), Alignment.Center) {
      Canvas(Modifier.size(12.dp)) { val w = size.width; val h = size.height; drawLine(p.bg.copy(alpha = ck), Offset(w * .1f, h * .55f), Offset(w * .4f, h * .85f), 2.dp.toPx(), StrokeCap.Round); drawLine(p.bg.copy(alpha = ck), Offset(w * .4f, h * .85f), Offset(w * .9f, h * .15f), 2.dp.toPx(), StrokeCap.Round) }
     }
    }
   }
   FlowRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Save", p.ok, sel != null) { st.saveJee(sel?.let { "2027-01-%02d".format(it) }); st.jeePicker = false }
    if (st.jee != null) Pill(p, "Clear", BAD) { st.saveJee(null); st.jeePicker = false }
    Pill(p, "Cancel") { st.jeePicker = false }
   }
  }
 }
}
@Composable fun Card(p: Pal, m: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
 val shape = RoundedCornerShape(18.dp)
 Column(m.padding(horizontal = PadH).padding(bottom = 12.dp).fillMaxWidth().clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(16.dp), content = content)
}
@Composable fun InsightsTab(p: Pal, st: UiState) {
 val tab = st.insTab
 val got = when (tab) { 1 -> EVENTS.mapNotNull { st.results[evId(it)] }; 2 -> EVENTS.mapNotNull { e -> if (e.full) null else st.results[advId(e)] }; else -> EVENTS.flatMap { e -> listOfNotNull(st.results[evId(e)], if (e.full) null else st.results[advId(e)]) } }
 val mainAvg = EVENTS.mapNotNull { st.results[evId(it)] }.let { l -> if (l.isEmpty()) -1f else l.map { it.pct }.average().toFloat() }
 val advAvg = EVENTS.mapNotNull { e -> if (e.full) null else st.results[advId(e)] }.let { l -> if (l.isEmpty()) -1f else l.map { it.pct }.average().toFloat() }
 val avg = if (got.isEmpty()) 0f else got.map { it.pct }.average().toFloat(); val best = got.maxByOrNull { it.pct }
 val subAvg = (0..2).map { s -> if (got.isEmpty()) 0f else got.map { it.subPct(s) }.average().toFloat() }
 val gap = st.goal - avg
 val note = if (got.isEmpty()) "Log your first test result to unlock trends and subject insights." else {
  val wk = subAvg.indices.minByOrNull { subAvg[it] }!!; val sk = subAvg.indices.maxByOrNull { subAvg[it] }!!
  val a = if (wk == sk) "" else "${SN[wk]} is your weakest subject at ${r0(subAvg[wk])}%, while ${SN[sk]} leads at ${r0(subAvg[sk])}%. Flag its topics for revision to lift your score fastest. "
  val b = if (got.size > 1) "Your latest score is ${if (got.last().pct >= got[got.size - 2].pct) "up" else "down"} ${Math.abs(r0(got.last().pct - got[got.size - 2].pct))} points on the previous test. " else ""
  a + b + (if (gap > 0) "You are ${r0(gap)} points below your ${st.goal}% target on average." else "You are above your ${st.goal}% target on average. Keep it steady.")
 }
 LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
  item { Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp)) { Tx("Insights", p.tx, 32f, FontWeight.ExtraBold, ls = -.8f); Seg2(p, listOf("All papers", "JEE Main", "Advanced"), st.insTab, Modifier.padding(top = 12.dp)) { st.insTab = it } } }
  item { Row(Modifier.padding(horizontal = PadH).padding(bottom = 12.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
   Stat(p, "${got.size}/${when (tab) { 1 -> 11; 2 -> 6; else -> 17 }}", "papers logged", Modifier.weight(1f)); Stat(p, "${r0(avg)}%", "average", Modifier.weight(1f)); Stat(p, best?.let { "${r0(it.pct)}%" } ?: "–", "best score", Modifier.weight(1f)) } }
  item { Card(p) {
   Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
    Column { Tx("Target score", p.mu, 13f); Tx("${st.goal}%", p.tx, 28f, FontWeight.ExtraBold, ls = -.6f) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill(p, "−5") { st.changeGoal(st.goal - 5); st.tick() }; Pill(p, "+5") { st.changeGoal(st.goal + 5); st.tick() } }
   }
   val a by animateFloatAsState((avg / st.goal).coerceIn(0f, 1f), tween(700), label = "g")
   Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.ok)) }
  } }
  if (tab == 0) item { Card(p) {
   Tx("By paper type", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
   listOf("Main + Full" to mainAvg, "Advanced" to advAvg).forEach { (n, v) -> val a by animateFloatAsState((v / 100f).coerceIn(0f, 1f), tween(800), label = "pt")
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
     Tx(n, p.tx, 13f, FontWeight.SemiBold, Modifier.width(92.dp))
     Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.M)) }
     Tx(if (v < 0) "–" else "${r0(v)}%", p.tx, 13f, FontWeight.Bold, Modifier.width(48.dp), align = TextAlign.End)
    } }
  } }
  item { Card(p) {
   Tx("Score trend", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
   Box { Trend(p, got.map { it.pct }, st.goal); Tx("100%", p.mu, 10f, m = Modifier.offset(0.dp, 2.dp)); Tx("50%", p.mu, 10f, m = Modifier.offset(0.dp, 74.dp)); Tx("0%", p.mu, 10f, m = Modifier.offset(0.dp, 146.dp)) }
   Tx("Dashed line is your target.", p.mu, 12f, m = Modifier.padding(top = 6.dp))
  } }
  item { Card(p) {
   Tx("Subject average", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
   (0..2).forEach { s -> val a by animateFloatAsState((subAvg[s] / 100f).coerceIn(0f, 1f), tween(800), label = "sa")
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
     Tx(SN[s], p.sub(s), 13f, FontWeight.SemiBold, Modifier.width(92.dp))
     Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(p.s2)) { Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(p.sub(s))) }
     Tx("${r0(subAvg[s])}%", p.tx, 13f, FontWeight.Bold, Modifier.width(48.dp), align = androidx.compose.ui.text.style.TextAlign.End)
    } }
  } }
  item { Card(p) { Tx("What to do next", p.tx, 18f, FontWeight.Bold, Modifier.padding(bottom = 6.dp)); Tx(note, p.mu, 14f, lh = 20f) } }
 }
}
@Composable fun Trend(p: Pal, pts: List<Float>, goal: Int) {
 var go by remember { mutableStateOf(false) }; LaunchedEffect(pts.size) { go = false; delay(60); go = true }
 val pg by animateFloatAsState(if (go) 1f else 0f, tween(1200, easing = FastOutSlowInEasing), label = "tr")
 Canvas(Modifier.fillMaxWidth().height(160.dp)) {
  val l = 34.dp.toPx(); val w = size.width - l - 10.dp.toPx(); val top = 8.dp.toPx(); val h = size.height - 16.dp.toPx()
  fun y(v: Float) = top + h * (1f - (v / 100f).coerceIn(0f, 1f))
  listOf(0f, 50f, 100f).forEach { drawLine(p.ln, Offset(l, y(it)), Offset(l + w, y(it)), 1.dp.toPx()) }
  drawLine(p.ok, Offset(l, y(goal.toFloat())), Offset(l + w, y(goal.toFloat())), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
  if (pts.isEmpty()) return@Canvas
  val xs = pts.indices.map { if (pts.size == 1) l + w / 2 else l + w * it / (pts.size - 1f) }
  clipRect(0f, 0f, l + (w + 10.dp.toPx()) * pg, size.height) {
   if (pts.size > 1) { val path = Path(); pts.forEachIndexed { i, v -> if (i == 0) path.moveTo(xs[i], y(v)) else path.lineTo(xs[i], y(v)) }
    drawPath(path, Brush.horizontalGradient(listOf(p.P, p.C, p.M), startX = l, endX = l + w), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)) }
   pts.forEachIndexed { i, v -> drawCircle(p.bg, radius = 6.dp.toPx(), center = Offset(xs[i], y(v))); drawCircle(p.M, radius = 6.dp.toPx(), center = Offset(xs[i], y(v)), style = Stroke(2.5.dp.toPx())) }
  }
 }
}

@Composable fun RowScope.Field(p: Pal, label: String, v: String, col: Color, num: Boolean = true, err: Boolean = false, on: (String) -> Unit) {
 val shape = RoundedCornerShape(12.dp)
 Column(Modifier.weight(1f)) {
  Tx(label, col, 12f, FontWeight.SemiBold)
  Box(Modifier.padding(top = 4.dp).fillMaxWidth().clip(shape).background(p.bg).border(if (err) 2.dp else 1.dp, if (err) BAD else p.ln, shape).padding(horizontal = 12.dp, vertical = 10.dp)) {
   BasicTextField(v, on, Modifier.fillMaxWidth(), singleLine = true, textStyle = TextStyle(color = p.tx, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = Body), cursorBrush = SolidColor(p.M), keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text))
  }
 }
}
@Composable fun ResultDialog(p: Pal, st: UiState, id: String) {
 val adv = id.endsWith("a"); val e = EVENTS.first { evId(it) == id.removeSuffix("a") }; val old = st.results[id]
 var a by remember { mutableStateOf(old?.p?.toString() ?: "") }; var b by remember { mutableStateOf(old?.c?.toString() ?: "") }; var c by remember { mutableStateOf(old?.m?.toString() ?: "") }
 var mx by remember { mutableStateOf((old?.mx ?: if (adv) 180 else 300).toString()) }; var rk by remember { mutableStateOf(if ((old?.rank ?: 0) > 0) old!!.rank.toString() else "") }; var note by remember { mutableStateOf(old?.note ?: "") }
 val sm = (mx.toIntOrNull() ?: 0) / 3f; val smTxt = if (sm % 1f == 0f) sm.toInt().toString() else "%.1f".format(sm)
 fun over(s: String) = (s.toIntOrNull() ?: 0) > sm || (s.toIntOrNull() ?: 0) < -sm
 val ok = a.toIntOrNull() != null && b.toIntOrNull() != null && c.toIntOrNull() != null && sm > 0 && !over(a) && !over(b) && !over(c); val shape = RoundedCornerShape(18.dp)
 Dialog(onDismissRequest = { st.editing = null }) {
  Column(Modifier.clip(shape).background(p.s1).border(1.dp, p.ln, shape).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
   Tx("${e.name}${if (e.full) "" else if (adv) " · JEE Advanced" else " · JEE Main"}", p.tx, 22f, FontWeight.ExtraBold, ls = -.4f)
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Field(p, "Physics", a, p.P, err = over(a)) { a = clampMark(it, sm) }; Field(p, "Chemistry", b, p.C, err = over(b)) { b = clampMark(it, sm) }; Field(p, "Maths", c, p.M, err = over(c)) { c = clampMark(it, sm) } }
   Tx(if (sm > 0) "Each subject is out of $smTxt" else "Enter max marks first", if (over(a) || over(b) || over(c)) BAD else p.mu, 12f)
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Field(p, "Max marks", mx, p.tx) { mx = it.filter { ch -> ch.isDigit() } }; Field(p, "Rank (optional)", rk, p.tx) { rk = it.filter { ch -> ch.isDigit() } } }
   Row { Field(p, "Note: mistakes, lessons", note, p.tx, false) { note = it } }
   FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Pill(p, "Save", p.ok, ok) { if (ok) { st.saveRes(Res(id, a.toInt(), b.toInt(), c.toInt(), mx.toInt(), rk.toIntOrNull() ?: 0, note.trim())); st.editing = null; st.tick() } }
    if (old != null) Pill(p, "Delete", BAD) { st.clearRes(id); st.editing = null }
    Pill(p, "Cancel") { st.editing = null }
   }
  }
 }
}
