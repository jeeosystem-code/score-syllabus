package com.score1.syllabus
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import org.json.JSONArray
import org.json.JSONObject
class MainActivity : ComponentActivity() {
 private lateinit var st: UiState
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val pr = getSharedPreferences("s1", 0); Cfg.ensure(this); val store = Store(this); st = UiState(store, pr)
  var d = store.all()
  if (d.isEmpty()) try { val a = JSONArray(pr.getString("keys", "[]")); val l = (0 until a.length()).map { a.getString(it) }; if (l.isNotEmpty()) { store.replace(l); d = l.toSet() } } catch (e: Exception) {}
  if (d.isEmpty() && !pr.getBoolean("seeded", false)) {
   val prog = try { assets.open("tracker.json").bufferedReader().use { it.readText() } } catch (e: Exception) { null }?.let { runCatching { JSONObject(it).optJSONObject("progress") }.getOrNull() }
   if (prog != null) { runCatching { st.importAll(prog.toString()) }; d = store.all() }
  }
  pr.edit().putBoolean("seeded", true).apply()
  st.crash = pr.getString("crash", null)
  val old = Thread.getDefaultUncaughtExceptionHandler()
  Thread.setDefaultUncaughtExceptionHandler { t, e -> try { pr.edit().putString("crash", e.stackTraceToString().take(2500)).commit() } catch (x: Throwable) {}; old?.uncaughtException(t, e) }
  st.done = d; st.theme = pr.getInt("theme", 0); store.mirror(d); st.weak = store.weak(); store.results().forEach { st.results[it.id] = it }
  if (Cfg.needsBuilder) { st.draft = Cfg.cur; st.builderOpen = true; pr.edit().putBoolean("builderShown", true).apply() }
  applyIntent(intent)
  setContent { App(st) }
 }
 override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); applyIntent(i) }
 private fun applyIntent(i: Intent?) { if (i == null) return; if (i.hasExtra("tab")) st.tab = i.getIntExtra("tab", 0); if (i.getBooleanExtra("jee", false) && Cfg.allExams().isNotEmpty()) st.examPick = 0 }
 override fun onPause() { super.onPause(); Widgets.refresh(this) }
}
