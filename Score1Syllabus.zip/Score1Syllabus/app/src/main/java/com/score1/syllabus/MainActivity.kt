package com.score1.syllabus
import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.webkit.*
import android.widget.FrameLayout
import android.widget.LinearLayout
fun isNight(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
class Bridge(private val c: Context, private val v: View?) {
 private val p = c.getSharedPreferences("s1", 0)
 @JavascriptInterface fun save(keys: String, total: Int) { p.edit().putString("keys", keys).putInt("total", total).apply(); ScoreWidget.refresh(c) }
 @JavascriptInterface fun load(): String = p.getString("keys", "[]") ?: "[]"
 @JavascriptInterface fun night(): Boolean = isNight(c)
 @JavascriptInterface fun tick() { val t = v; t?.post { t.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) } }
}
class MainActivity : Activity() {
 private lateinit var wv: WebView
 private lateinit var splash: FrameLayout
 private val h = Handler(Looper.getMainLooper())
 private var t0 = 0L; private var gone = false
 private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
 private fun hideSplash() {
  if (gone) return; gone = true
  splash.animate().alpha(0f).setDuration(350).withEndAction { (splash.parent as? ViewGroup)?.removeView(splash) }.start()
 }
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val night = isNight(this)
  val bg = if (night) 0xFF0C1020.toInt() else 0xFFF2F3F9.toInt()
  window.statusBarColor = bg; window.navigationBarColor = bg
  if (!night) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
  wv = WebView(this); wv.setBackgroundColor(bg); wv.overScrollMode = View.OVER_SCROLL_NEVER; wv.isVerticalScrollBarEnabled = false
  wv.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true; textZoom = 100 }
  wv.addJavascriptInterface(Bridge(this, wv), "AndroidBridge")
  // launch overlay: three bars wipe in, like the stripe on the page
  splash = FrameLayout(this); splash.setBackgroundColor(bg)
  val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
  val colors = intArrayOf(0xFF4CC9F0.toInt(), 0xFFFFB547.toInt(), 0xFFB58CFF.toInt()); val widths = intArrayOf(150, 110, 70)
  colors.forEachIndexed { i, k ->
   val bar = View(this); bar.background = GradientDrawable().apply { setColor(k); cornerRadius = dp(8).toFloat() }
   val lp = LinearLayout.LayoutParams(dp(widths[i]), dp(16)); if (i > 0) lp.topMargin = dp(12); col.addView(bar, lp)
   bar.pivotX = 0f; bar.scaleX = 0f
   bar.animate().scaleX(1f).setStartDelay(150L + i * 140L).setDuration(520).setInterpolator(DecelerateInterpolator(2f)).start()
  }
  splash.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
  val root = FrameLayout(this); root.addView(wv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); root.addView(splash, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
  setContentView(root); t0 = System.currentTimeMillis()
  wv.webViewClient = object : WebViewClient() {
   override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
    if (r.url.host != "app.local") return null
    return try { WebResourceResponse("text/html", "utf-8", assets.open("index.html")) } catch (e: Exception) { null }
   }
   override fun onPageFinished(v: WebView, url: String) { h.postDelayed({ hideSplash() }, maxOf(0L, 1000L - (System.currentTimeMillis() - t0))) }
  }
  h.postDelayed({ hideSplash() }, 3500)
  wv.loadUrl("https://app.local/index.html")
 }
 override fun onBackPressed() {
  wv.evaluateJavascript("(function(){var d=document.getElementById('bk');if(d&&d.open){d.close();return 1}return 0})()") { r -> if (r != "1") finish() }
 }
 override fun onPause() { super.onPause(); ScoreWidget.refresh(this) }
}
