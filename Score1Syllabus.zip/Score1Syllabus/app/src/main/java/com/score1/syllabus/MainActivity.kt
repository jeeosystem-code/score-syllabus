package com.score1.syllabus
import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.webkit.*
class Bridge(private val c: Context) {
 private val p = c.getSharedPreferences("s1", 0)
 @JavascriptInterface fun save(keys: String, total: Int) { p.edit().putString("keys", keys).putInt("total", total).apply(); ScoreWidget.refresh(c) }
 @JavascriptInterface fun load(): String = p.getString("keys", "[]") ?: "[]"
 @JavascriptInterface fun night(): Boolean = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
}
class MainActivity : Activity() {
 private lateinit var wv: WebView
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val night = Bridge(this).night()
  val bg = if (night) 0xFF0C1020.toInt() else 0xFFF2F3F9.toInt()
  window.statusBarColor = bg; window.navigationBarColor = bg
  if (!night) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
  wv = WebView(this); wv.setBackgroundColor(bg); setContentView(wv)
  wv.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true }
  wv.addJavascriptInterface(Bridge(this), "AndroidBridge")
  wv.webViewClient = object : WebViewClient() {
   override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
    if (r.url.host != "app.local") return null
    return try { WebResourceResponse("text/html", "utf-8", assets.open("index.html")) } catch (e: Exception) { null }
   }
  }
  wv.loadUrl("https://app.local/index.html")
 }
 override fun onBackPressed() { finish() }
 override fun onPause() { super.onPause(); ScoreWidget.refresh(this) }
}
