package com.score1.syllabus
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import org.json.JSONArray
class MainActivity : ComponentActivity() {
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val pr = getSharedPreferences("s1", 0); val store = Store(this); val st = UiState(store, pr)
  var d = store.all()
  if (d.isEmpty()) try { val a = JSONArray(pr.getString("keys", "[]")); val l = (0 until a.length()).map { a.getString(it) }; if (l.isNotEmpty()) { store.replace(l); d = l.toSet() } } catch (e: Exception) {}
  st.done = d; st.theme = pr.getInt("theme", 0); store.mirror(d)
  setContent { App(st) }
 }
 override fun onPause() { super.onPause(); ScoreWidget.refresh(this) }
}
