package com.score1.syllabus
val TOTAL: Int get() = TESTS.sumOf { t -> listOf(t.p, t.c, t.m).sumOf { m -> m.values.sumOf { it.size } } }
fun vis(mode: Int, f: Char) = mode == 0 || f == ' ' || (mode == 1 && f == 'm') || (mode == 2 && f == 'a')
fun subFrac(t: Test, s: Int, mode: Int, done: Set<String>): Float {
 val m = when (s) { 0 -> t.p; 1 -> t.c; else -> t.m }; var n = 0; var k = 0
 m.values.forEach { l -> l.forEach { x -> val f = if (x.startsWith("m:")) 'm' else if (x.startsWith("a:")) 'a' else ' '; val tx = if (f == ' ') x else x.substring(2); if (vis(mode, f)) { n++; if ("${t.id}|${"PCM"[s]}|$tx" in done) k++ } } }
 return if (n == 0) 0f else k / n.toFloat()
}
fun testPct(t: Test, mode: Int, done: Set<String>): Float = (0..2).sumOf { subFrac(t, it, mode, done).toDouble() }.toFloat() / 3f
fun overallPct(mode: Int, done: Set<String>): Float = if (TESTS.isEmpty()) 0f else TESTS.sumOf { testPct(it, mode, done).toDouble() }.toFloat() / TESTS.size
