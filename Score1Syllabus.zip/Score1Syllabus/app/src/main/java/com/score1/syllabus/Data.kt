package com.score1.syllabus
class Test(val id:Int,val d:String,val ph:Int,val p:Map<String,List<String>>,val c:Map<String,List<String>>,val m:Map<String,List<String>>)
val TESTS=listOf(
Test(1,"2026-11-03",0,mapOf("" to listOf("Modern Physics","KTG & Thermodynamics","Calorimetry","Heat Transfer","Thermal Expansion","Elasticity","Heat Engine","Heat Pump & Entropy","m:Semiconductor")),mapOf("Physical" to listOf("Thermodynamics","Thermochemistry","a:Ideal gas","a:Real gas"),"Inorganic" to listOf("Chemical bonding","p-block")),mapOf("" to listOf("Complex Numbers","Matrices","Determinants","FOM","Straight Line","Circle"))),
Test(2,"2026-11-23",0,mapOf("" to listOf("Electrostatics","Gravitation","Mechanics till Momentum")),mapOf("Inorganic" to listOf("Co-ordination Compound","a:Metallurgy"),"Organic" to listOf("Aromatic Compounds","Biomolecules / Amino Acids","Practical Organic Chemistry","a:Polymer")),mapOf("" to listOf("Parabola","Ellipse","Hyperbola","Compound Angle","Quadratic Equations","Sequence & Series"))),
Test(3,"2026-12-02",1,mapOf("" to listOf("EMI","AC","MEC","SHM","Damped & Forced Oscillations","m:Bar Magnet","m:Magnetic Materials")),mapOf("Physical" to listOf("Atomic Structure","Chemical Kinetics","a:Solid state"),"Organic" to listOf("Carboxylic Acid & Derivatives","Amines & Other Nitrogen Compounds","Name reactions","Nucleophilic addition to Carbonyl Compounds")),mapOf("" to listOf("Binomial Theorem","Logarithm","Permutation & Combination","Probability","Statistics","a:Trigonometric Equation"))),
Test(4,"2026-12-11",1,mapOf("" to listOf("Rigid body Dynamics","Geometrical Optics","m:Microscope & Telescope")),mapOf("Physical" to listOf("Liquid Solution","Chemical Equilibrium","Ionic Equilibrium"),"Inorganic" to listOf("Salt analysis","a:H-atom and its Compound","a:Environmental Chemistry")),mapOf("" to listOf("Vectors","3-D","Sets","Relation","Functions","Inverse Trigonometric Functions"))),
Test(5,"2026-12-20",2,mapOf("" to listOf("Current Electricity","Error Analysis","Capacitor","Fluid")),mapOf("Inorganic" to listOf("Periodic table","d-block and f-block","a:s-block"),"Organic" to listOf("Oxidation & Reduction","Alcohols & Ether","Alkyl Halide (Substitution / Elimination)")),mapOf("" to listOf("Limits","Continuity & Differentiability","Method of differentiation","Application of derivative"))),
Test(6,"2026-12-29",2,mapOf("" to listOf("Wave on String","Sound Waves","Wave Optics","E.M. Waves","Polarization","Diffraction & Resolving Power")),mapOf("Physical" to listOf("Electrochemistry","Redox","Mole Concept","a:Surface Chemistry"),"Organic" to listOf("Complete isomerism","GOC (electronic effects, acid-base)","Separation Technique","Attacking Reagents","IUPAC Nomenclature","Hydrocarbon","a:Chemistry in everyday life")),mapOf("" to listOf("Indefinite Integration","Definite Integration","Differential Equation","Area under the curve")))
)
val TOTAL=TESTS.sumOf{t->listOf(t.p,t.c,t.m).sumOf{m->m.values.sumOf{it.size}}}
fun vis(mode: Int, f: Char) = mode == 0 || f == ' ' || (mode == 1 && f == 'm') || (mode == 2 && f == 'a')
fun subFrac(t: Test, s: Int, mode: Int, done: Set<String>): Float {
 val m = when (s) { 0 -> t.p; 1 -> t.c; else -> t.m }; var n = 0; var k = 0
 m.values.forEach { l -> l.forEach { x -> val f = if (x.startsWith("m:")) 'm' else if (x.startsWith("a:")) 'a' else ' '; val tx = if (f == ' ') x else x.substring(2); if (vis(mode, f)) { n++; if ("${t.id}|${"PCM"[s]}|$tx" in done) k++ } } }
 return if (n == 0) 0f else k / n.toFloat()
}
fun testPct(t: Test, mode: Int, done: Set<String>): Float = (0..2).sumOf { subFrac(t, it, mode, done).toDouble() }.toFloat() / 3f
fun overallPct(mode: Int, done: Set<String>): Float = TESTS.sumOf { testPct(it, mode, done).toDouble() }.toFloat() / TESTS.size
