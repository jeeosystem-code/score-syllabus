package com.score1.syllabus
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.*
import android.widget.RemoteViews
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.sqrt

abstract class BaseWidget(private val kind: Int) : AppWidgetProvider() {
 override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { Widgets.update(c, m, it, kind) } }
 override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) { Widgets.update(c, m, id, kind) }
 override fun onReceive(c: Context, i: Intent) {
  super.onReceive(c, i)
  if (i.action == Intent.ACTION_DATE_CHANGED || i.action == "android.intent.action.TIME_SET" || i.action == Intent.ACTION_TIMEZONE_CHANGED) Widgets.refresh(c)
 }
}
class CountdownWidget : BaseWidget(1)
class JeeWidget : BaseWidget(2)
class ProgressWidget : BaseWidget(3)
class ScoresWidget : BaseWidget(4)

class Pn(val c: Context, val w: Int, val h: Int, val d: Float) {
 private val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
 private fun col(l: String, k: String) = Color.parseColor(if (night) k else l)
 val bg = col("#FFFFFF", "#151A31"); val ln = col("#D9DCEB", "#272E52"); val tx = col("#10142E", "#EDEFFA"); val mu = col("#5B6280", "#8F97BA"); val s2 = col("#E8EAF4", "#1D2342")
 val cP = col("#0A84B8", "#4CC9F0"); val cC = col("#C77700", "#FFB547"); val cM = col("#7B3FE4", "#B58CFF"); val ok = col("#0E9F6E", "#5EE6A8"); val bad = Color.parseColor("#FF6B6B")
 val bmp: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp); val p = Paint(Paint.ANTI_ALIAS_FLAG)
 val bold: Typeface = c.resources.getFont(R.font.bg24_bold); val xb: Typeface = c.resources.getFont(R.font.bg36_extrabold); val med: Typeface = c.resources.getFont(R.font.is_medium)
 val k = minOf(w / d / 150f, h / d / 150f).coerceIn(.75f, 1.5f); val pad = 14 * d
 init {
  val r = 22 * d; p.color = bg; cv.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), r, r, p)
  p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = ln; cv.drawRoundRect(d / 2, d / 2, w - d / 2, h - d / 2, r, r, p); p.style = Paint.Style.FILL
  val sp = Path().apply { addRoundRect(pad, pad, w - pad, pad + 4 * d, 2 * d, 2 * d, Path.Direction.CW) }
  cv.save(); cv.clipPath(sp); val seg = (w - 2 * pad) / 3; listOf(cP, cC, cM).forEachIndexed { i, cl -> p.color = cl; cv.drawRect(pad + seg * i, pad, pad + seg * (i + 1), pad + 4 * d, p) }; cv.restore()
 }
 fun txt(s: String, x: Float, y: Float, sz: Float, color: Int, tf: Typeface, al: Paint.Align = Paint.Align.LEFT): Float { p.style = Paint.Style.FILL; p.textSize = sz; p.typeface = tf; p.color = color; p.textAlign = al; cv.drawText(s, x, y, p); return p.measureText(s) }
 fun bar(x: Float, y: Float, wd: Float, ht: Float, frac: Float, color: Int) { p.style = Paint.Style.FILL; p.color = s2; cv.drawRoundRect(x, y, x + wd, y + ht, ht / 2, ht / 2, p); if (frac > 0f) { p.color = color; cv.drawRoundRect(x, y, x + wd * maxOf(minOf(frac, 1f), ht / wd), y + ht, ht / 2, ht / 2, p) } }
 fun ring(cx: Float, cy: Float, r: Float, sw: Float, frac: Float, color: Int) {
  p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = s2; cv.drawCircle(cx, cy, r, p)
  if (frac > 0f) { p.color = color; p.strokeCap = Paint.Cap.ROUND; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * minOf(frac, 1f), false, p); p.strokeCap = Paint.Cap.BUTT }
  p.style = Paint.Style.FILL
 }
}

object Widgets {
 private val classes = listOf<Class<*>>(ScoreWidget::class.java, CountdownWidget::class.java, JeeWidget::class.java, ProgressWidget::class.java, ScoresWidget::class.java)
 fun refresh(c: Context) { val m = AppWidgetManager.getInstance(c); classes.forEachIndexed { k, cl -> m.getAppWidgetIds(ComponentName(c, cl)).forEach { update(c, m, it, k) } } }
 fun update(c: Context, m: AppWidgetManager, id: Int, kind: Int) {
  Cfg.ensure(c)
  val o = m.getAppWidgetOptions(id); var d = c.resources.displayMetrics.density
  val port = c.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
  var w = (o.getInt(if (port) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0).let { if (it <= 0) 150 else it } * d).toInt()
  var h = (o.getInt(if (port) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0).let { if (it <= 0) 150 else it } * d).toInt()
  if (w < 50 || h < 50) return
  if (w * h > 1_000_000) { val f = sqrt(1_000_000f / (w * h)); w = (w * f).toInt(); h = (h * f).toInt(); d *= f }
  val bmp = try { when (kind) { 0 -> ScoreWidget.draw(c, w, h, d); 1 -> countdown(c, w, h, d); 2 -> jee(c, w, h, d); 3 -> progress(c, w, h, d); else -> scores(c, w, h, d) } } catch (e: Exception) { return }
  val rv = RemoteViews(c.packageName, R.layout.widget); rv.setImageViewBitmap(R.id.img, bmp)
  val intent = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
  if (kind == 2) intent.putExtra("jee", true); if (kind == 4) intent.putExtra("tab", 1)
  rv.setOnClickPendingIntent(R.id.img, PendingIntent.getActivity(c, kind, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
  m.updateAppWidget(id, rv)
 }
 private fun doneSet(c: Context): Set<String> = try { val a = JSONArray(c.getSharedPreferences("s1", 0).getString("keys", "[]")); (0 until a.length()).map { a.getString(it) }.toSet() } catch (e: Exception) { emptySet() }
 private fun nameOf(id: String): String { val pr = parseRid(id); val e = EVENTS.firstOrNull { evId(it) == pr.first }; return if (e == null) id else e.name + (if (e.papers.size > 1) " · " + (e.papers.getOrNull(pr.second)?.name ?: "") else "") }

 private fun countdown(c: Context, w: Int, h: Int, d: Float): Bitmap {
  val q = Pn(c, w, h, d); val k = q.k; val pad = q.pad; val today = LocalDate.now(); val nx = EVENTS.firstOrNull { !it.d.isBefore(today) }
  if (nx == null) { q.txt(if (EVENTS.isEmpty()) "No tests" else "All tests", pad, h * .5f, 18 * d * k, q.tx, q.bold); q.txt(if (EVENTS.isEmpty()) "yet" else "done", pad, h * .5f + 22 * d * k, 13 * d * k, q.mu, q.med); return q.bmp }
  val n = ChronoUnit.DAYS.between(today, nx.d).toInt()
  q.txt(nx.name, pad, pad + 30 * d * k, 14 * d * k, q.tx, q.bold)
  q.txt(if (n == 0) "Today" else "$n", pad, h * .64f, (if (n == 0) 40 else 58) * d * k, q.cM, q.xb)
  if (n > 0) q.txt(if (n == 1) "day to go" else "days to go", pad, h * .64f + 20 * d * k, 12 * d * k, q.mu, q.med)
  q.txt(nx.d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + ", " + nx.d.format(DM), pad, h - pad, 12 * d * k, q.mu, q.med)
  return q.bmp
 }
 private fun jee(c: Context, w: Int, h: Int, d: Float): Bitmap {
  val q = Pn(c, w, h, d); val k = q.k; val pad = q.pad; val today = LocalDate.now()
  val ex = Cfg.cur.target; val date = pd(ex?.date)
  q.txt(ex?.name ?: "Target exam", pad, pad + 30 * d * k, 14 * d * k, q.tx, q.bold)
  if (date == null) { q.txt(if (ex == null) "No target" else "Set your", pad, h * .56f, 18 * d * k, q.tx, q.bold); q.txt(if (ex == null) "exam yet" else "exam date", pad, h * .56f + 22 * d * k, 18 * d * k, q.tx, q.bold); q.txt("Tap to choose", pad, h - pad, 12 * d * k, q.mu, q.med); return q.bmp }
  val n = ChronoUnit.DAYS.between(today, date).toInt()
  q.txt(if (n < 0) "Done" else if (n == 0) "Today" else "$n", pad, h * .64f, (if (n <= 0) 40 else 58) * d * k, q.cP, q.xb)
  if (n > 0) q.txt(if (n == 1) "day to go" else "days to go", pad, h * .64f + 20 * d * k, 12 * d * k, q.mu, q.med)
  q.txt(date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + ", " + date.format(DM) + " " + date.year, pad, h - pad, 12 * d * k, q.mu, q.med)
  return q.bmp
 }
 private fun progress(c: Context, w: Int, h: Int, d: Float): Bitmap {
  val q = Pn(c, w, h, d); val k = q.k; val pad = q.pad; val mode = c.getSharedPreferences("s1", 0).getInt("mode", 0); val done = doneSet(c)
  val ov = overallPct(mode, done); val sAvg = (0..2).map { s -> TESTS.map { subFrac(it, s, mode, done) }.average().toFloat() }
  val top = pad + 14 * d; val bottom = h - pad; val cy = (top + bottom) / 2f; val wide = w > h * 1.5f
  val r = minOf((bottom - top) / 2f, if (wide) h * .5f else w / 2f - pad); val sw = r * .22f; val cx = if (wide) pad + r + 2 * d else w / 2f
  q.ring(cx, cy, r - sw / 2, sw, ov, q.ok)
  q.txt("${Math.round(ov * 100)}%", cx, cy + r * .2f, r * .6f, q.tx, q.xb, Paint.Align.CENTER)
  if (wide) {
   val x0 = cx + r + 20 * d; val rh = (bottom - top) / 3f; val cols = listOf(q.cP, q.cC, q.cM)
   if (x0 < w - pad - 80 * d) (0..2).forEach { s -> val y = top + rh * s
    q.txt(SN[s], x0, y + 15 * d * k, 12 * d * k, cols[s], q.bold); q.txt("${Math.round(sAvg[s] * 100)}%", w - pad, y + 15 * d * k, 12 * d * k, q.tx, q.bold, Paint.Align.RIGHT)
    q.bar(x0, y + 21 * d * k, w - pad - x0, 5 * d, sAvg[s], cols[s]) }
  } else if (h > 140 * d) q.txt("syllabus done", w / 2f, h - pad, 12 * d * k, q.mu, q.med, Paint.Align.CENTER)
  return q.bmp
 }
 private fun spark(q: Pn, vals: List<Float>, goal: Int, l: Float, t: Float, r: Float, b: Float) {
  val d = q.d; val p = q.p
  fun y(v: Float) = t + (b - t) * (1f - (v / 100f).coerceIn(0f, 1f))
  p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = q.ln; q.cv.drawLine(l, y(0f), r, y(0f), p)
  p.color = q.ok; p.strokeWidth = 1.5f * d; p.pathEffect = DashPathEffect(floatArrayOf(6 * d, 5 * d), 0f); q.cv.drawLine(l, y(goal.toFloat()), r, y(goal.toFloat()), p); p.pathEffect = null
  val xs = vals.indices.map { if (vals.size == 1) (l + r) / 2 else l + (r - l) * it / (vals.size - 1f) }
  if (vals.size > 1) {
   val path = Path(); vals.forEachIndexed { i, v -> if (i == 0) path.moveTo(xs[i], y(v)) else path.lineTo(xs[i], y(v)) }
   p.shader = LinearGradient(l, 0f, r, 0f, intArrayOf(q.cP, q.cC, q.cM), null, Shader.TileMode.CLAMP); p.strokeWidth = 2.5f * d; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; q.cv.drawPath(path, p); p.shader = null
  }
  vals.forEachIndexed { i, v -> p.style = Paint.Style.FILL; p.color = q.bg; q.cv.drawCircle(xs[i], y(v), 4 * d, p); p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = q.cM; q.cv.drawCircle(xs[i], y(v), 4 * d, p) }
  p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
 }
 private fun scores(c: Context, w: Int, h: Int, d: Float): Bitmap {
  val q = Pn(c, w, h, d); val k = q.k; val pad = q.pad
  val store = Store(c); val res = try { store.results().associateBy { it.id } } finally { store.close() }
  val all = EVENTS.flatMap { e -> e.papers.indices.mapNotNull { res[rid(e, it)] } }
  q.txt("Latest score", pad, pad + 28 * d * k, 12 * d * k, q.mu, q.med)
  if (all.isEmpty()) { q.txt("No results yet", pad, pad + 58 * d * k, 18 * d * k, q.tx, q.bold); q.txt("Log a test in the app", pad, pad + 78 * d * k, 12 * d * k, q.mu, q.med); return q.bmp }
  val last = all.last(); val prev = all.getOrNull(all.size - 2); val wide = w > h * 1.6f
  val by = pad + 28 * d * k + 36 * d * k
  val tw = q.txt("${last.total}", pad, by, 38 * d * k, q.tx, q.xb); q.txt("/${last.mx}", pad + tw + 4 * d, by, 14 * d * k, q.mu, q.med)
  val y2 = by + 19 * d * k; val wp = q.txt("${Math.round(last.pct)}%", pad, y2, 13 * d * k, q.tx, q.bold)
  if (prev != null) { val dl = Math.round(last.pct - prev.pct); q.txt((if (dl >= 0) "  +" else "  ") + dl + " pts", pad + wp, y2, 12 * d * k, if (dl >= 0) q.ok else q.bad, q.bold) }
  q.txt(nameOf(last.id), pad, y2 + 17 * d * k, 11 * d * k, q.mu, q.med)
  val goal = c.getSharedPreferences("s1", 0).getInt("goal", 80); val pts = all.map { it.pct }
  if (wide) spark(q, pts, goal, w * .56f, pad + 16 * d, w - pad, h - pad) else spark(q, pts, goal, pad, y2 + 34 * d * k, w - pad, h - pad)
  return q.bmp
 }
}
